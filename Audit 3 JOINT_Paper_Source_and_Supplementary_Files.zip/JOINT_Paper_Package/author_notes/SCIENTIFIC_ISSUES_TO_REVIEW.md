# SCIENTIFIC_ISSUES_TO_REVIEW

**Revision note (Phase 3, 6 October 2026).** The Introduction of
`manuscript/FINAL_SUBMISSION.tex` was rewritten for presentation: the same
mathematical claims, the same citations and the same cross-references, in the
block order motivation → applications → chronological literature (cyclic and
negacyclic → constacyclic → Galois hulls → distribution studies → finite rings
and affine algebras) → explicit gap (the three counting questions) → present
contribution → results → roadmap. No reference was added, removed or
re-attributed, and no theorem, lemma, proposition or corollary was renamed.
Because the order of first citation changed, `FINAL_SUBMISSION.bbl` was
reordered accordingly; the printed numbers `[1]`–`[32]` therefore differ from
the Phase-2.2 build. The Introduction PDF is **not** rebuilt in the package: the
file `manuscript/FINAL_SUBMISSION.pdf` is still the Phase-2.2 build, so the
manuscript must be recompiled before it is read as final.

Status after Phase 2.2 (`FINAL_Q1_REFINED_V3`). Only items that require author judgment
are listed, each with location, issue, why it matters and suggested action.
Nothing listed here was changed silently unless marked **[closed]**.

**Closed since Phase 1.** A5 (displayed F₃₂ values) is resolved: the coefficient
vector and largest coefficient were removed from the main text as instructed, so no
previously unpublished numbers remain in the paper; the underlying data stay in
`computed_data/`. The Phase-1 report is preserved as
`build_q1/SCIENTIFIC_ISSUES_TO_REVIEW_phase1.md`. Phase 2.2 changed only the
layout (page measure, leading, heading sizes) and the Introduction prose; no
mathematical item in this list was affected, and item D4 was updated to the new
page count.

---

## A. Mathematical

**A1. Range of the twist exponent $k$ — still open.**
*Location:* §2.1 ($0\le k<e$) and Remark 2.10.
*Issue:* the exponent is measured against the base field $\F_q=\F_{p^e}$, not
against a component field $K_s=\F_{p^{d_s}}$, $d_s=em_s$. Hence the Hermitian value
$k=d_s/2$ is outside the hypothesis range on components with $m_s>1$, which is why
Remark 2.10 only claims Hermitian behaviour for $k=e/2$ on the components with
$m_s=1$.
*Why it matters:* a referee may ask whether the framework deliberately excludes
Hermitian duality on extension components, or whether $0\le k<d_s$ was intended.
*Suggested action:* either add one sentence in §2.1 explaining that $0\le k<e$
keeps $\sigma_{\A,k}$ a nontrivial base-field semilinear map (as used in
Lemma 2.8), or extend the hypothesis to $0\le k<d_s$ and re-check Lemma 2.8 and
the compatibility condition. **No change was made.**

**A2. Example 5.1 has no explicit ambient algebra.** *Location:* Example 5.1.
*Issue:* the example speaks of "four labeled $\F_4$ components" (written
$\F_4^{\times4}$ in Table 3, i.e. a tensor product of four copies of $\F_4$, not a
field extension); a square-free presentation of that $\A$ is not written down.
*Why it matters:* purely expository — the orbit data and counts are correct.
*Suggested action:* optional one-clause parenthetical; no mathematical change.

**A3. Incompatibility is componentwise.** *Location:* §6, last paragraph.
*Issue:* "for incompatible components the hull is trivial (Remark 3.7)" is a
componentwise statement and does not assert that the global hull vanishes.
*Why it matters:* avoid a possible misreading.
*Suggested action:* optional clause "hence the corresponding summand of the global
hull". Left as delivered.

**A4. Precision of Remark 3.8(i) wording.** *Location:* Remark 3.8.
*Issue:* "agree only when the square of the Frobenius happens to fix the dual
subspace" is an informal phrasing of the correct equivalence.
*Suggested action:* optional restatement as
$\sigma_{s,k}^2(\Dk(C))=\Dk(C)$. No mathematical change.

## B. Notation

**B1. §-references in the reading guide.** *Location:* start of §4.
*Issue:* the guide refers to "§§4.1–4.2"; if the author renumbers subsections for a
journal class file, only this sentence and the §1 guide need attention.
*Suggested action:* none if the structure is kept.

**B2. $\eta$ vs $\dim\Hull$.** *Location:* Table 1 and §4.3.
*Issue:* the table pairs "$\kappa(C)$, $\eta_k(C)$" with the joint enumerator, while
the narrative also writes $\dim_{\F_q}\Hull_{\A,k}(C(J))$.
*Why it matters:* consistent as it stands (the symbols are introduced explicitly),
but the table can be extended if the author prefers the $\eta_k$ notation to
dominate.
*Suggested action:* none, or add $\eta_k(C)=\dim_{\F_q}\Hull_{\A,k}(C)$ to the
table. Notation was not renamed.

**B3. $\F_4^{\times4}$ and $\F_{16}/\F_4$ labels in Table 3.** *Location:* Table 3.
*Issue:* compact family labels; $\F_4^{\times4}$ denotes four labeled $\F_4$
components, not a field extension.
*Suggested action:* adjust if a house style prefers spelled-out labels.

**B4. Generic degree symbol removed.** **[closed]** The Introduction's "$k=d/2$
over a field of degree $d$" used an undefined $d$; it now reads "the Euclidean and
Hermitian cases are the values $k=0$ and $k$ equal to half the degree of the
field".

## C. Literature/reference

**C1. Preprint versus published version of Debnath et al. — still open.**
*Location:* §1 (citation key `debnathAffine2026`; it was reference `[29]` before
the Phase-3 renumbering of the bibliography), §3.3 (comparison paragraph).
*Issue:* the comparison of hull formulas is made against **arXiv:2412.08512v1**
(Thm. 8 there). The published version is *Discrete Mathematics* **349**(2):114750
(2026), which is what `\cite{debnathAffine2026}` prints; its theorem numbering and
wording were not available in the supplied project files.
*Why it matters:* the numbering cited must exist in the version the reader can
obtain; citing a preprint after publication is acceptable but should be explicit.
*Suggested action:* at submission, open the published article, check the theorem
number and hypothesis list, and either (a) cite the published theorem number, or
(b) keep the preprint attribution as now worded ("the formula is Thm. 8 of the
preprint version (arXiv:2412.08512v1) of `debnathAffine2026`"). The wording was clarified in
Phase 2 but **no bibliographic field was guessed**.

**C2. Verify final bibliographic data for the 2026 entries.**
*Location:* `references.bib` entries `zhang2026`, `debnathSmall2026`,
`eldinLeroy2026`, `bouyuklieva2026`, `eldinSole2026`, `aliabadi2026`.
*Issue:* these were ahead-of-print or early-issue when the package was prepared
(volume/page/article numbers such as *Adv. Math. Commun.* 22:1–18,
*J. Algebra Appl.* 2750160, *Des. Codes Cryptogr.* 94:39).
*Suggested action:* confirm volume, page range and DOI at submission. Nothing was
added, deleted or renumbered in content.

**C3. `debnathAffinePreprint` is present but uncited.**
*Location:* `references.bib`.
*Issue:* the preprint now appears only as an inline arXiv locator, so the entry is
unused by BibTeX.
*Suggested action:* either delete the entry or turn the inline locator into a
proper citation; both are acceptable. No change was made to `references.bib`.

**C4. Novelty wording — no action needed, recorded for transparency.**
*Location:* §1 contribution paragraph.
*Issue:* the text states explicitly that items (i)–(iii) assemble established
descriptions and that the joint enumeration (iv) is the paper's result. No "first"
or priority claim appears; the citation-order numbering changed in Phase 1 because
the literature paragraph was reorganized.

## D. Journal policy

**D1. AI-assisted-tools statement — author confirmation required.**
*Location:* Statements and Declarations.
*Issue:* the package contains no target-journal policy file, and `README.txt`
(untouched) contains no submission instructions, so it cannot be determined whether
a disclosure is required or in what form. The statement is therefore **retained**
as a neutral disclosure naming the tool, the assisted tasks (mathematical checking,
verification code, language editing) and the author's responsibility.
*Suggested action:* check the chosen journal's author guidelines (Elsevier:
"Declaration of generative AI in scientific writing"; Springer Nature and Wiley:
their own forms; some journals: none). Delete or reformat accordingly. AI is not
presented as an author and no scientific decision is attributed to it.

**D2. Data/supplementary wording.** **[prepared]** A ready-to-upload
supplementary folder has now been assembled as `submission/supplementary/`
(the five programs with `requirements.txt`, the ten CSV tables, and a neutral
`README.md` that contains none of the project-internal wording of item E2). The
readme was smoke-tested: `run_examples.py` reproduces the exact statistics of
Table 3 (F8: 128 codes, mean $3/2$; F32: $2^{31}$ selections, mean $15/2$;
$\F_4^{\times4}$: 4096 codes, mean 4). Nothing was modified in the original
`project/programs/` and `project/computed_data/`.
*Location:* Data availability; Appendix A, final sentence.
*Issue:* both statements say the programs and coefficient tables accompany the
manuscript as supplementary material. That is accurate now that the folder is
prepared and can be uploaded as-is.
*Suggested action:* upload the material, or reduce the wording to "available from
the author on request". No repository link was invented.

**D3. Corresponding-author e-mail — still missing.**
*Location:* author block.
*Issue:* the source contains no e-mail address (as noted in the untouched
`README.txt`).
*Suggested action:* add before submission.

**D4. Length and class file.**
*Location:* whole manuscript.
*Issue:* after the Phase-2.2 layout change to a paper-style measure (10 pt,
150 mm text width, A4) the manuscript is 26 pages: 24 pp. of manuscript
(including the declarations, Appendix A and the Conclusions) and two pages of
references. The earlier 31-page figure referred to the previous 120 mm measure.
*Suggested action:* if the target journal imposes a page limit or supplies a class
file (`elsarticle`, Springer `sn-jnl`, `IEEEtran`), port the source; if a reduction
is needed, Appendix A is the first candidate, followed by Table 3. No proofs should
be compressed.

**D5. MSC codes.** *Location:* front matter. 94B05, 94B15, 05A15 retained; add
94B65 if the quantum-coding motivation is to be emphasized.

## E. Reproducibility

**E1. The delivered `FINAL.tex` (original) does not compile.** *Location:*
`project/FINAL.tex`, line 108, and the pipeline figure.
*Issue:* `\mathcal` outside math mode and a stray `$` in the abstract, plus
`\includegraphics{flowchart.png}` while the package ships `flowchart.png.png`; the
shipped `FINAL.pdf` also contains abstract wording that the `.tex` does not
produce. `FINAL_Q1_REFINED.tex` is self-contained (figures inlined) and compiles
cleanly with `references.bib` and the supplied `.bst`.
*Suggested action:* none for the submission; keep the original as the archive copy.

**E2. `README.txt` and `computed_data/README.md` contain project-internal
language.** *Location:* package root and `computed_data/`.
*Issue:* internal QC folder names, an external audit checkpoint archive, "personal
download", "not a promise or authorization to publish", and a stale note that the
length-31 sample "has not yet been run" (it has: sampled individual-code checks are
reported in Appendix A).
*Suggested action:* if these files are uploaded as supplementary material, replace
them with a short neutral description. Left untouched per instruction.

**E3. Sampled versus exhaustive checks.** *Location:* Appendix A.
*Issue:* the length-31 individual-code comparison used a random subsample; the
count of all 2³¹ selections comes from the exact recurrence.
*Suggested action:* none — the refined appendix states this distinction explicitly,
and no sampling detail is presented as validation of the full enumeration.
