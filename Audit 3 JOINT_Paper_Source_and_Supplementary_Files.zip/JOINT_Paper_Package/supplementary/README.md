# Supplementary material

This folder accompanies the paper *Joint Code-Dimension and k-Galois-Hull Enumerators for Simple-Root Constacyclic Codes over Square-Free Affine Algebras*.

## Programs

- `exact_enumerator.py` — exact orbit-based enumerator using Python integers and rational arithmetic.
- `run_examples.py` — regenerates the example joint-enumerator CSVs and a summary JSON.
- `hull_check.py` — direct finite-field linear-algebra check of hull dimensions (requires the packages in `requirements.txt`).
- `checked_hull_check.py` — a precondition-checking wrapper for `hull_check.py`.
- `requirements.txt` — pinned Python dependencies for the direct-check scripts.

Run the table-generation examples with `python3 run_examples.py --output generated` from this directory. It writes generated files into the directory named `generated` (or the path passed to `--output`).

`data/` contains the ten CSV files bundled with the source archive. The CSVs include joint and conditional distributions for the listed examples.
