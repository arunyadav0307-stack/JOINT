#!/usr/bin/env python3
"""
Generate Figure 3 (Fig. 1.png): Joint multiplicity distribution of code
dimension kappa and k-Galois hull dimension eta_k for F_32 with n = 31,
lambda = 1, and k = 1, together with the conditional expectation curve
E[eta_k | kappa].
"""

import math
import os
import matplotlib.pyplot as plt
import numpy as np
from verify_all import trace_recurrence_enumerator, moments_from_enumerator


def main():
    orbits = [(1, 1)] + [(10, 1)] * 3
    E = trace_recurrence_enumerator(orbits)
    _, _, _, _, cond = moments_from_enumerator(E)

    grid = np.full((16, 32), np.nan)
    for (kap, eta), mult in E.items():
        if mult > 0:
            grid[eta, kap] = math.log10(mult)

    kappas = sorted(cond.keys())
    cond_means = [float(cond[k]["mean"]) for k in kappas]

    fig, ax = plt.subplots(figsize=(8.0, 5.5), dpi=200)
    im = ax.imshow(
        grid,
        origin="lower",
        aspect="auto",
        extent=[-0.5, 31.5, -0.5, 15.5],
        cmap="viridis",
    )
    ax.plot(
        kappas,
        cond_means,
        "o--",
        color="#1f77b4",
        markerfacecolor="white",
        markeredgecolor="black",
        markersize=4,
        linewidth=1.3,
        label=r"$\mathbb{E}[\eta_k \mid \kappa]$",
    )
    ax.set_xlabel(r"Code dimension $\kappa$")
    ax.set_ylabel(r"$k$-Galois hull dimension $\eta_k$")
    ax.set_title(r"$\mathbb{F}_{32},\ n = 31,\ \lambda = 1,\ k = 1$")
    ax.set_xticks(range(0, 32, 5))
    ax.set_yticks(range(0, 16, 5))
    ax.legend(loc="upper left", frameon=False)
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label(r"$\log_{10}\ \mathrm{multiplicity}$")
    fig.tight_layout()

    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Fig3_regenerated.png")
    fig.savefig(out_path, dpi=200)
    print(f"Saved regenerated Figure 3 to: {out_path}")


if __name__ == "__main__":
    main()
