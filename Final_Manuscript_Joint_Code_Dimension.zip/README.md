# Manuscript & Supplementary Reproducibility Package

**Title:** Joint Code-Dimension and $k$-Galois-Hull Enumerators for Simple-Root Constacyclic Codes over Square-Free Affine Algebras  
**Author:** Arun Kumar Yadav (School of Basic and Applied Sciences, K.R. Mangalam University, Gurugram, Haryana, India)  
**2020 MSC:** 94B05, 94B15, 05A15

---

## 1. Overview of Contents

This archive contains the complete LaTeX source files, bibliography files, compiled PDF manuscript, Python verification programs, and generated exact coefficient tables described in Section 5 and Appendix A of the manuscript.

```text
.
├── main.tex                                     # Complete LaTeX manuscript source
├── main.pdf                                     # Compiled 26-page camera-ready PDF
├── references.bib                               # BibTeX database (all 33 references with DOIs)
├── main.bbl                                     # Pre-compiled bibliography for standalone compilation
├── Fig. 1.png                                   # Figure 3: Joint multiplicity heatmap & E[eta_k | kappa] for F_32, n = 31
├── README.md                                    # Documentation and reproducibility instructions
├── code/
│   ├── verify_all.py                            # Exact orbit enumeration & direct finite-field linear-algebra verification
│   └── generate_fig3.py                         # Script to regenerate Figure 3 from exact enumerator coefficients
└── tables/
    ├── table2_F8_n7_joint_enumerator.csv        # Table 2 / Example 5.2 joint multiplicities (q = 8, n = 7)
    ├── example5_1_F4x4_n5_joint_enumerator.csv  # Example 5.1 joint multiplicities (65 nonzero terms)
    ├── example5_3_F4xF16_n5_joint_enumerator.csv# Example 5.3 joint multiplicities (40 nonzero terms)
    ├── example5_4_F32_n31_joint_enumerator.csv  # Example 5.4 joint multiplicities (248 nonzero terms, sum = 2^31)
    ├── example5_4_F32_n31_conditional_moments.csv # Exact rational Phi_0, Phi_1, Phi_2, E[eta_k|kappa], Var(eta_k|kappa)
    ├── benchmark_q2_n21_joint_enumerator.csv    # Sangwisut et al. (2015) Example 16 benchmark (q = 2, n = 21)
    ├── benchmark_q3_n16_joint_enumerator.csv    # Sangwisut et al. (2015) Example 17 benchmark (q = 3, n = 16)
    ├── table3_all_families_summary.csv          # Summary of all families in Table 3
    └── summary_results.json                     # Machine-readable JSON summary of all families in Table 3
```

---

## 2. Compiling the LaTeX Manuscript

The manuscript `main.tex` uses standard packages (`amsmath`, `amssymb`, `amsthm`, `mathtools`, `mathrsfs`, `booktabs`, `tabularx`, `tikz`, `natbib`, `hyperref`) and includes the pre-compiled `main.bbl` so that it compiles out-of-the-box without requiring a custom `.bst` file:

```bash
pdflatex main.tex
pdflatex main.tex
```

If you wish to regenerate the bibliography from `references.bib` using `sn-mathphys-num-local.bst` (or another Springer/Elsevier `.bst` style), uncomment the `\bibliographystyle` and `\bibliography{references}` lines at the end of `main.tex` and run:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

---

## 3. Running the Computational Verification Suite

The verification script `code/verify_all.py` requires **only the Python 3 standard library** (`fractions`, `math`, `itertools`, `csv`, `json`, `random`) and performs all exact integer and rational calculations with zero floating-point rounding:

```bash
python3 code/verify_all.py
```

### What `code/verify_all.py` Verifies:
1. **Two-Way Exact Enumerator Verification (Propositions 4.4 and 4.15):**
   Evaluates $\mathscr{E}(u, z)$ via both the two-state transfer-matrix trace recursion (Proposition 4.15) and the closed-form binomial orbit formula (Proposition 4.4) followed by orbit convolution, verifying exact coefficient-by-coefficient equality across all families in Examples 5.1–5.4 and Table 3.
2. **Exact Moments and LCD Counts (Corollaries 4.7–4.14):**
   Verifies total labeled code counts $2^{\sum_s |\mathcal{F}_s|}$, labeled LCD counts $2^{\sum_s |\mathcal{O}_s|}$, unconditional mean $\mathbb{E}[\eta_k]$ and variance $\operatorname{Var}(\eta_k)$ (including the $a_O = 2$ correction term), and exact rational conditional moments $\Phi_j(\kappa)$.
3. **Independent Finite-Field Linear-Algebra Checks (Section 5.2):**
   Constructs the monic irreducible factors of $x^n - \lambda_s$ over $\mathbb{F}_3, \mathbb{F}_4, \mathbb{F}_8, \mathbb{F}_9, \mathbb{F}_{16}, \mathbb{F}_{25}$ (characteristics $2, 3, 5$), forms generator matrices $B$ in coefficient coordinates for every labeled factor selection, computes $\dim \operatorname{Hull}_k(C)$ directly via matrix rank over the component field, and verifies 100% agreement with the cyclic $1$-to-$0$ boundary formula of Proposition 3.11. Also checks a seeded random subsample of $50$ codes of length $n = 31$ over $\mathbb{F}_{32}$ (`seed=2026`).
4. **Published Benchmark Recovery:**
   Recovers the Euclidean cyclic hull counts of Sangwisut et al. (2015), Examples 16 and 17: $16$ codes of hull dimension $6$ among the $64$ binary cyclic codes of length $21$, and $32$ codes of hull dimension $4$ among the $128$ ternary cyclic codes of length $16$.

To regenerate the Figure 3 plot (`Fig3_regenerated.png`), run (requires `matplotlib` and `numpy`):

```bash
python3 code/generate_fig3.py
```
