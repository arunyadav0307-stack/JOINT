GALOIS HULL MANUSCRIPT — COMPLETE PERSONAL DOWNLOAD

MAIN FILES
  FINAL.tex — editable manuscript with Arun Kumar Yadav's author details
  FINAL.pdf — matching compiled manuscript, 28 pages
  references.bib — bibliography
  sn-mathphys-num-local.bst — required bibliography style
  FINAL.bbl — generated bibliography
  build.sh / BUILD_INSTRUCTIONS.txt — LaTeX build instructions
  programs/ — Python programs and pinned field-check dependencies
  computed_data/ — saved exact coefficient and conditional-statistics CSV files

AUTHOR DETAILS
Confirmed name, affiliation, no specific funding, no competing interests and
sole-author review/approval are included. The email has deliberately not been
invented. Add your corresponding-author email in FINAL.tex before submission.
The author definition is near the top, after the title. For example, add a new
author line using \\ followed by \texttt{your actual email}. Use only your real
address. Rebuild after this edit and recheck the 28-page limit.

COMPILE THE PAPER
Install TeX Live with latex-extra, fonts-recommended and lmodern (or equivalent).
Run: sh build.sh
Alternatively run pdflatex FINAL.tex, bibtex FINAL, then pdflatex FINAL.tex twice.
Figures are embedded in the source; no external images are needed.

EXACT ENUMERATOR PROGRAM (NO EXTRA PYTHON PACKAGES)
  cd programs
  python run_examples.py --output generated
This computes the five joint-polynomial examples with exact integer/rational
arithmetic and checks dense versus closed-form coefficients. It starts from
the specified orbit data; it does not perform finite-field factorization or
independently verify those orbits. The F32 example counts 2^31 selections via
the recurrence, NOT by enumerating 2^31 generator matrices.

DIRECT FINITE-FIELD CHECKER
Historically tested with Python 3.13.14 and the versions in requirements.txt.
  cd programs
  python -m pip install -r requirements.txt
  python -c "from checked_hull_check import check; print(check(8,7,1,1))"
For the sampled length-31 check:
  python -c "from checked_hull_check import check; print(check(32,31,1,1,sample=150,seed=0))"
Use the checked wrapper for individual calls. It is limited to compatible,
simple-root, single-field components (extension weight m_s=1). The integer
lambda argument uses the finite-field library's encoding, not real arithmetic.
It is not a general mixed-ring or arbitrary extension-component checker.
The original hull_check.py is included unchanged. The field-check campaign was
not rerun during this packaging update; its prior audit evidence remains in
the separately delivered cumulative FINAL_CHECKPOINT.zip.

STATUS AND USE
This ZIP includes programs for your personal use, as requested. It is not a
promise or authorization to publish a code supplement. For a journal upload,
use the manuscript/source/bibliography/style files; do not automatically upload
the programs, computed data or this personal-use README as a supplement.
The A-linear code-family scope and author approval have been confirmed.
Full published-theorem overlap with the closest papers remains unresolved;
the paper retains qualified contribution wording. No novelty guarantee is made.
The previous FINAL_CHECKPOINT.zip is preserved unchanged as the audit history.
