#!/bin/sh
# Requires TeX Live with standard LaTeX packages and BibTeX.
set -eu
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error -recorder FINAL.tex
bibtex FINAL
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error -recorder FINAL.tex
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error -recorder FINAL.tex
