# Supplementary reproducibility material

**Manuscript:** *Joint Code-Dimension and k-Galois-Hull Enumerators for Simple-Root Constacyclic Codes over Square-Free Affine Algebras*  
**Target journal:** *Finite Fields and Their Applications*  
**2020 MSC:** 94B05, 94B15, 05A15

This archive contains the computational scripts and exact result tables cited in Section 5.2 and Appendix A of the manuscript. It is a supplementary-material package; the manuscript source, bibliography, and the submitted figure file are supplied separately with the main manuscript package.

## Contents

### Scripts

- `code/verify_all.py` — exact enumerator computations, moment/LCD checks, independent finite-field linear-algebra checks, and published benchmark recovery. Uses only the Python 3 standard library.
- `code/generate_fig3.py` — regenerates manuscript Figure 3's heatmap and conditional-mean curve from the exact enumerator. Requires `numpy` and `matplotlib`; it writes `fig_galois_hull.png` at the archive root, matching the filename used by `main.tex`.

### Result tables

- `tables/table2_F8_n7_joint_enumerator.csv` — joint multiplicities for Example 5.2.
- `tables/example5_1_F4x4_n5_joint_enumerator.csv` — joint multiplicities for Example 5.1.
- `tables/example5_3_F4xF16_n5_joint_enumerator.csv` — joint multiplicities for Example 5.3.
- `tables/example5_4_F32_n31_joint_enumerator.csv` — joint multiplicities for Example 5.4.
- `tables/example5_4_F32_n31_conditional_moments.csv` — exact conditional moments for Example 5.4.
- `tables/table3_all_families_summary.csv` — summary of the families in Table 3.
- `tables/summary_results.json` — machine-readable summary of the reported computations.
- `tables/benchmark_q2_n21_joint_enumerator.csv` and `tables/benchmark_q3_n16_joint_enumerator.csv` — benchmark enumerators for the binary and ternary cases discussed in Section 5.2.

## Reproduction

From the extracted archive directory, run:

```bash
python3 code/verify_all.py
```

To regenerate Figure 3, install `numpy` and `matplotlib`, then run:

```bash
python3 code/generate_fig3.py
```

The calculations use exact integer and rational arithmetic for the reported coefficients and moments. The generated figure is a reproducible visualization of the exact enumerator; it is not a substitute for the separate figure file included with the main manuscript package.
