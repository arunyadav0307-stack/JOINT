# Submission package — FINAL_SUBMISSION

**Manuscript.** *Joint Code-Dimension and k-Galois-Hull Enumerators for Simple-Root
Constacyclic Codes over Square-Free Affine Algebras* — A. K. Yadav,
K.R. Mangalam University, Gurugram, Haryana, India.

## 1. Manuscript files (upload these to the journal)

| File | Role |
|---|---|
| `FINAL_SUBMISSION.tex` | Manuscript source (self-contained; all figures inlined as vector TikZ). |
| `references.bib` | Bibliography database (33 entries, 32 cited). |
| `sn-mathphys-num-local.bst` | Bibliography style used by the manuscript. |
| `FINAL_SUBMISSION.bbl` | Pre-built bibliography (used if the system does not run BibTeX). |
| `FINAL_SUBMISSION.pdf` | Compiled manuscript, **26 pages**, 0 errors, 0 overfull boxes, 0 undefined references. |

**Build order:** `pdflatex FINAL_SUBMISSION` → `bibtex FINAL_SUBMISSION` →
`pdflatex` → `pdflatex`. Only `references.bib` and `sn-mathphys-num-local.bst` are
required alongside the source; there are no external image files (every figure is
vector TikZ inside the `.tex`).

## 2. Companion reports (for the author / cover letter, not for the journal)

| File | Content |
|---|---|
| `PAPER_STRUCTURE_AND_VALIDATION_REPORT.pdf` | Section-wise structure (Table 1), inventory of all 43 numbered statements, the seven-layer validation program, contribution-to-statement coverage map, comparison with five published Q1 papers, package contents. |
| `WHOLE_PAPER_STYLE_AUDIT.pdf` | Whole-paper language and style audit: vocabulary scan, sentence statistics, writing conventions against published papers, the 26 sentences edited in the two language passes, and the frozen-content verification table. |
| `INTRODUCTION_STYLE_EVIDENCE.pdf` | Verbatim quotations from five published papers' Introductions, block by block, matched against this manuscript's Introduction. |

## 3. State of the manuscript (verified on this build)

* Build: 26 pages, 0 errors, 0 overfull/underfull boxes, 0 undefined references.
* **43 numbered statements** and **33 proofs**: text-identical to the approved
  version (checked automatically environment by environment).
* **Citation order**: first-use order of all 32 references unchanged; numbered
  reference list identical to the previously approved PDF.
* **Mathematics, numerical values, Figure 3 data, CSV files and programs**: not
  modified in any pass of this round.
* Language: no prose sentence exceeds 44 words (median 24); no machine-marker
  vocabulary; US spelling; booktabs tables.

## 4. Before upload (author actions — nothing was invented here)

1. **Corresponding-author e-mail** — insert in the author block (the source
   package contains no address).
2. **2026 bibliographic entries** (`zhang2026`, `debnathSmall2026`, `eldinLeroy2026`,
   `bouyuklieva2026`, `eldinSole2026`, `aliabadi2026`) — confirm volume/page/DOI
   against the publisher versions.
3. **Reference [29]** — the manuscript quotes Thm. 8 of the preprint version
   (arXiv:2412.08512v1); if the published *Discrete Mathematics* version is to be
   cited, check its theorem number and update that one sentence.
4. **Supplementary material** — upload `programs/` and `computed_data/`, or reduce
   the data-availability wording to "available from the author on request".
5. **AI-assistance statement** — retained as a neutral disclosure; check the target
   journal's policy (Springer/Elsevier provide their own templates).

Details of items 1–5 are tracked with locations in `../SCIENTIFIC_ISSUES_TO_REVIEW.md`.
