"""Recompute five joint enumerators from the manuscript's orbit inputs.
Uses Python integers/Fraction; no third-party packages or field factorization.
Run: python run_examples.py --output generated
"""
import argparse,csv,json
from pathlib import Path
from exact_enumerator import dense_enumerator,closed_enumerator,invariants,statistics
CASES={'F4_four_components':[(1,1),(2,2)]*4,'F8_length7':[(1,1),(6,1)],'F16_over_F4':[(1,2),(4,2)],'F4xF16_mixed':[(1,1),(2,2),(1,2),(4,2)],'F32_length31':[(1,1),(10,1),(10,1),(10,1)]}
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',default='generated');a=p.parse_args();out=Path(a.output);out.mkdir(parents=True,exist_ok=True);results={}
 for name,orbits in CASES.items():
  poly,diagnostics=dense_enumerator(orbits);assert poly==closed_enumerator(orbits);summary=invariants(poly,orbits)
  with (out/(name+'_joint.csv')).open('w',newline='') as f:
   w=csv.writer(f);w.writerow(['code_dimension','hull_dimension','multiplicity']);w.writerows((k,h,c) for (k,h),c in sorted(poly.items()))
  results[name]={'orbits':orbits,'terms':len(poly),'statistics':{k:str(v) for k,v in summary.items()}}
  if name=='F8_length7':results[name]['conditional_k3']={k:str(v) for k,v in statistics(poly,3).items()}
 (out/'summary.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
if __name__=='__main__':main()
