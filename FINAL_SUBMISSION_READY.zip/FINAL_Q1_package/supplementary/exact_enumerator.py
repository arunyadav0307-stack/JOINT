"""Exact compatible-orbit coefficient enumeration, newly implemented in Phase04.
No field factorization or direct code/dual computation is performed here.
Input pairs (a,w) are orbit lengths and positive base-field dimension weights.
Python integers/Fraction only; no floating-point coefficient arithmetic.
"""
from collections import Counter
from fractions import Fraction
from math import comb


def validate(orbits):
    result=[]
    for item in orbits:
        if not isinstance(item,(tuple,list)) or len(item)!=2:
            raise ValueError('an orbit must be a pair (length, weight)')
        a,w=item
        if type(a) is not int or type(w) is not int or a<1 or w<1:
            raise ValueError('length and weight must be positive Python integers')
        result.append((a,w))
    return tuple(result)


def dense_enumerator(orbits, *, hull_cap=None):
    """Dense version of the manuscript recurrence, with diagnostic operation counts.
    Default rectangular bound is W//2. An explicitly larger bound is accepted
    for clipping-invariance checks. Bounds below the attainable maximum are rejected.
    Both starting states use the SAME immutable previous global array.
    """
    orbits=validate(orbits)
    W=sum(a*w for a,w in orbits);NF=sum(a for a,w in orbits)
    maximum_hull=sum((a//2)*w for a,w in orbits)
    if hull_cap is None:hull_cap=W//2
    if type(hull_cap) is not int or hull_cap<maximum_hull:
        raise ValueError('hull_cap omits attainable coefficients')
    H=hull_cap;stride=H+1;size=(W+1)*stride
    G=[0]*size;G[0]=1
    stats={'W':W,'N_F':NF,'orbits':len(orbits),'hull_cap':H,'rectangle_slots':size,'transition_cell_visits':0,'merge_cell_visits':0,'integer_additions':0,'discarded_nonzero_transitions':0,'max_coefficient_bits_seen':1,'array_slot_bound':6*size}
    for a,w in orbits:
        updated=[0]*size
        for start in (0,1):
            current=[[0]*size,[0]*size]
            current[start]=G.copy()
            for _ in range(a):
                following=[[0]*size,[0]*size]
                for source in (0,1):
                    for destination in (0,1):
                        dk=w*(1-destination);dh=w*source*(1-destination)
                        for kappa in range(W+1):
                            offset=kappa*stride
                            for eta in range(H+1):
                                stats['transition_cell_visits']+=1
                                value=current[source][offset+eta]
                                if not value:continue
                                if kappa+dk>W or eta+dh>H:
                                    stats['discarded_nonzero_transitions']+=1;continue
                                index=(kappa+dk)*stride+eta+dh
                                following[destination][index]+=value
                                stats['integer_additions']+=1
                                stats['max_coefficient_bits_seen']=max(stats['max_coefficient_bits_seen'],following[destination][index].bit_length())
                current=following
                del following
            for index,value in enumerate(current[start]):
                stats['merge_cell_visits']+=1
                if value:
                    updated[index]+=value;stats['integer_additions']+=1
                    stats['max_coefficient_bits_seen']=max(stats['max_coefficient_bits_seen'],updated[index].bit_length())
        G=updated
    poly={(k,h):G[k*stride+h] for k in range(W+1) for h in range(H+1) if G[k*stride+h]}
    assert stats['transition_cell_visits']==8*NF*size
    assert stats['merge_cell_visits']==2*len(orbits)*size
    return poly,stats


def sparse_unclipped(orbits):
    """Same combinatorial recurrence, separate sparse storage, no support clipping.
    This is a clipping/storage comparator, not an independent mathematical formula.
    """
    G={(0,0):1}
    for a,w in validate(orbits):
        result=Counter()
        for start in (0,1):
            state={(start,k,h):c for (k,h),c in G.items()}
            for _ in range(a):
                following=Counter()
                for (r,k,h),v in state.items():
                    following[0,k+w,h+w*r]+=v
                    following[1,k,h]+=v
                state=following
            for (end,k,h),v in state.items():
                if end==start:result[k,h]+=v
        G=dict(result)
    return G


def closed_orbit(a,w):
    validate([(a,w)])
    poly={(0,0):1,(a*w,0):1}
    for j in range(1,a):
        for r in range(1,min(j,a-j)+1):
            numerator=a*comb(j-1,r-1)*comb(a-j-1,r-1)
            value,remainder=divmod(numerator,r)
            assert remainder==0
            poly[w*j,w*r]=value
    return poly


def convolve(left,right):
    out=Counter()
    for (k,h),x in left.items():
        for (l,i),y in right.items():out[k+l,h+i]+=x*y
    return dict(out)


def closed_enumerator(orbits):
    """Independent formula evaluation: run-composition coefficients and convolution."""
    result={(0,0):1}
    for a,w in validate(orbits):result=convolve(result,closed_orbit(a,w))
    return result


def statistics(poly,dimension=None):
    entries=[(h,c) for (k,h),c in poly.items() if dimension is None or k==dimension]
    total=sum(c for h,c in entries)
    if not total:return None
    first=sum(h*c for h,c in entries)
    second_factorial=sum(h*(h-1)*c for h,c in entries)
    mean=Fraction(first,total)
    variance=Fraction(second_factorial+first,total)-mean**2
    assert variance>=0
    return {'count':total,'Phi1':first,'Phi2':second_factorial,'mean':mean,'variance':variance}


def invariants(poly,orbits):
    orbits=validate(orbits);W=sum(a*w for a,w in orbits);NF=sum(a for a,w in orbits)
    assert sum(poly.values())==2**NF
    assert poly.get((0,0))==1 and poly.get((W,0))==1
    for (k,h),c in poly.items():
        assert type(c) is int and c>0 and 0<=h<=min(k,W-k)
        assert poly.get((W-k,h))==c
    assert sum(c for (k,h),c in poly.items() if h==0)==2**len(orbits)
    # z=1 must count independent factor inclusion by total weight.
    dimension={0:1}
    for a,w in orbits:
        for _ in range(a):
            new=Counter(dimension)
            for k,c in dimension.items():new[k+w]+=c
            dimension=dict(new)
    marginal=Counter()
    for (k,h),c in poly.items():marginal[k]+=c
    assert dict(marginal)==dimension
    stats=statistics(poly)
    mean=sum((Fraction(a*w,4) for a,w in orbits if a>=2),Fraction(0))
    variance=sum((Fraction(w*w,4) if a==2 else Fraction(a*w*w,16) if a>=3 else Fraction(0) for a,w in orbits),Fraction(0))
    assert stats['mean']==mean and stats['variance']==variance
    return stats
