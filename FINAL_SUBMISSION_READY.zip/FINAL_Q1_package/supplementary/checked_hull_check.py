"""Internal precondition wrapper; original hull_check.py is preserved unchanged.
One compatible simple-root field component, m_s=1 only. This is not a general
incompatible-twist/extension-component/ring implementation. Domain checks do not
alter the supplied scientific kernel. Run with explicit positive sample count
when exhaustive enumeration would exceed max_exhaustive.
"""
from math import gcd
import galois
import hull_check


def check(q,n,lam,k,sample=None,seed=0,*,max_exhaustive=262144):
    if any(type(x) is not int for x in (q,n,lam,k,seed,max_exhaustive)):
        raise ValueError('q,n,lam,k,seed and max_exhaustive must be Python integers')
    if q<2 or n<1 or seed<0 or max_exhaustive<1:
        raise ValueError('invalid field order, length, seed or enumeration limit')
    GF=galois.GF(q)
    if not 0<=k<GF.degree:raise ValueError('require 0<=k<d for the m_s=1 scope')
    if gcd(n,GF.characteristic)!=1:raise ValueError('simple-root length required')
    if not 0<lam<q:raise ValueError('lam must encode a nonzero field element')
    twist=GF(lam)
    if twist**(1+GF.characteristic**(GF.degree-k))!=1:
        raise ValueError('this checker requires a compatible twist; incompatible hull theorem is separate')
    if sample is not None and (type(sample) is not int or sample<1):
        raise ValueError('sample must be None or a positive integer')
    if sample is None:
        M=galois.Poly.Degrees([n,0],[1,-twist],field=GF)
        factors,multiplicities=M.factors()
        if any(x!=1 for x in multiplicities):raise ValueError('repeated factors excluded')
        if 2**len(factors)>max_exhaustive:
            raise ValueError('exhaustive enumeration limit exceeded; supply a positive sample')
    return hull_check.check(q,n,lam,k,sample=sample,seed=seed)
