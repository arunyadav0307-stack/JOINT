# Supplementary material

This folder accompanies the manuscript *Joint Code-Dimension and k-Galois-Hull
Enumerators for Simple-Root Constacyclic Codes over Square-Free Affine Algebras*.
It contains the programs that generate the tables of Section 5 and the coefficient
tables they produce. No mathematical statement of the paper depends on these
files; they are provided so that every reported number can be regenerated.

## Programs

| File | Purpose |
|---|---|
| `exact_enumerator.py` | Evaluates the joint enumerator from orbit data with exact integer/rational arithmetic (trace recursion of Proposition 4.15 and the closed form of Proposition 4.4). |
| `hull_check.py` | Computes hull dimensions of individual codes directly from the definitions by finite-field linear algebra. |
| `checked_hull_check.py` | Cross-checks the two methods of `hull_check.py` against each other. |
| `run_examples.py` | Reproduces the families of Table 3 (Examples 5.1–5.4). |
| `requirements.txt` | Python dependencies. |

## Data

The twelve CSV files are the joint and conditional distributions produced by the
programs for the families of Table 3:

* `F8_length7_joint.csv`, `F8_length7_conditional.csv` — Example 5.2 (Table 2).
* `F32_length31_joint.csv`, `F32_length31_conditional.csv` — Example 5.4 (Figure 3).
* `F4_four_components_*`, `F4xF16_mixed_*`, `F16_over_F4_*` — Examples 5.1 and 5.3
  and the extension-weight family.

Each `*_joint.csv` lists coefficients $[u^\kappa z^\eta]\,\mathscr{E}(u,z)$; each
`*_conditional.csv` lists the dimension-conditioned hull statistics. All values
are exact integers or reduced rationals.

## Regenerating the tables

```
python3 run_examples.py        # reproduces the distributions of Table 3
python3 exact_enumerator.py    # evaluates the enumerator from orbit data
```

The scripts require only the standard library and the packages listed in
`requirements.txt`.
