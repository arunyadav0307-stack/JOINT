# Paper 2 Project Status — Controlled by Assistant

## Working title
**Joint Code-Dimension and $k$-Galois-Hull Enumerators for Repeated-Root Constacyclic Codes over Square-Free Affine Algebras**

## Ownership / handling
Assistant will handle the research-writing workflow end to end:
- literature-positioning and novelty checks;
- theorem statements and formal proofs;
- computational verification and supplementary code;
- figures, tables and worked examples;
- complete `elsarticle` LaTeX manuscript;
- bibliography, highlights, cover letter and submission checklist;
- revision support after co-author/referee comments.

The user/co-authors will only be asked for items that cannot responsibly be assumed at the end:
1. final author order, affiliations and acknowledgements/funding;
2. Paper 1's status at submission time (for disclosure/citation);
3. final approval and submission through the corresponding author's journal account.

## Default assumptions (unless the user says otherwise)
- Same author team and affiliations as Paper 1.
- First-choice journal: *Finite Fields and Their Applications*.
- Blueprint of record: `docs/BLUEPRINT.md` (v1.0, inside this repository). It supersedes the earlier roadmap.
- Counting remains labeled and $\mathcal A$-linear; support-trapezoid attainability will only be stated as a theorem if/when its proof is completed.
- No fabricated literature claims: every nearest-neighbour comparison must pass the final search protocol in Blueprint Section 13.

## Phase plan and status
- [x] Phase 0 — Blueprint, pilot computations, figures, tables and code package completed.
- [ ] Phase 1 — Formal Setting + Duality sections (Lemmas 3.2–3.4; Euclidean-dual recheck; dual generator; compatibility; incompatible case).
- [ ] Phase 2 — Hull min-formula, transfer matrix and Main Theorem with full proof.
- [ ] Phase 3 — Consequences: marginals, LCD invariance, hull values, moments, conditional law, extremal classes; support proposition decision gate.
- [ ] Phase 4 — Algorithm/complexity and worked examples; harden supplementary factorisation code.
- [ ] Phase 5 — Introduction, literature comparison, abstract/highlights, conclusions.
- [ ] Phase 6 — Full internal audit: notation, indices, theorem cross-references, table regeneration, referee-risk register.
- [ ] Phase 7 — Submission package: LaTeX source, PDF build instructions, supplementary ZIP, cover letter, declarations.

## Current phase
**Phase 1 — to be drafted first in `manuscript/main.tex`.**

## Quality gates
- No theorem enters the manuscript without either a complete proof in the draft or an explicit TODO marker.
- Every numerical table must be regenerable by a script in `code/`.
- Every example must state both $\lambda_{s,0}$ and $\lambda_s=\lambda_{s,0}^M$.
- The $a_O=1$ orbit case is checked separately in every moment formula.
- Final literature search is repeated within seven days of submission.
