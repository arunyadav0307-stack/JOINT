# Paper 2 — Repeated-Root Joint $k$-Galois-Hull Enumerators

**Working title:** *Joint Code-Dimension and $k$-Galois-Hull Enumerators for Repeated-Root Constacyclic Codes over Square-Free Affine Algebras*

This repository is the single master copy for Paper 2. It supersedes the scattered Arena workspace copies.

## Start here

1. **`PROJECT_STATUS.md`** — ownership, assumptions, phase plan, and quality gates.
2. **`docs/BLUEPRINT.md`** — the complete research blueprint (concepts, theorem/proof roadmaps, formulas, figures, tables, code design, referee risks, literature protocol).
3. **`manuscript/main.tex`** — the working `elsarticle` manuscript (front matter and section architecture; Phase 1 proofs next).

## Repository map

| Path | Contents |
|---|---|
| `manuscript/` | LaTeX source, Elsevier class/style, bibliography |
| `code/` | Exact enumerator, tests, independent finite-field verification, table/figure generator |
| `figures/` | Manuscript figures in PNG (preview) and PDF (LaTeX) |
| `tables/` | Exact CSV/JSON data and the verification log |
| `docs/` | Blueprint and project documentation |
| `notes/` | Scratch mathematical notes that are worth versioning |

## Reproduce the computations

From the repository root:

```bash
python3 code/test_rr_enumerator.py
python3 code/generate_tables_figures.py
python3 code/verify_rr.py --quick
python3 code/verify_rr.py
```

All counts use exact Python integers and `fractions.Fraction`; floating point is used only for plots.

## Mathematical status labels

The blueprint distinguishes **[READY]** derivations, **[PROOF-TARGET]** statements whose proof is not yet complete, **[COMPUTED]** evidence, and **[CHECK]** literature/convention items. Nothing labelled proof-target should be promoted to a theorem in the manuscript until its proof is written and audited.

## Privacy recommendation

Keep this repository **private** until the authors decide on submission/preprint timing. Do not mix it into a public Paper 1 repository by default.
