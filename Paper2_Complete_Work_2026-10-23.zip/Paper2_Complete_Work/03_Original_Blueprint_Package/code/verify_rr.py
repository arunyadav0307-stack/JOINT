#!/usr/bin/env python3
"""
Independent finite-field verification for the repeated-root formulas.

For each test family this script:
  1. factors x^{n'} - lambda0 over K (Paper 1's finite-field routines);
  2. builds g_e = prod f_i^{e_i}, 0 <= e_i <= M, a divisor of
     (x^{n'} - lambda0)^M = x^n - lambda0^M;
  3. computes the k-Galois hull dimension DIRECTLY from a generator matrix
     and the Gram matrix B * sigma(B)^T (no orbit formula);
  4. compares with sum_i deg(f_{tau(i)}) * min(e_i, M-e_{tau(i)});
  5. for exhaustive families, compares the full joint histogram with
     rr_enumerator.trace_dp_global.

It imports the FiniteField implementation from Paper 1's verification suite.
Run from the workspace root:
    python3 Paper2_RepeatedRoot_Blueprint/code/verify_rr.py [--quick]
"""
import argparse, itertools, os, random, sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', '..', 'paper1', 'code'))

from verify_all import FiniteField, factor_xn_minus_lambda  # Paper 1 code
from rr_enumerator import trace_dp_global


def orbit_data(K, factors, k):
    tau = {}
    for i, f in enumerate(factors):
        rec = K.reciprocal_sigma_inv(f, k)
        tau[i] = factors.index(rec)
    seen, cycles = set(), []
    for i in range(len(factors)):
        if i not in seen:
            cyc, j = [], i
            while j not in seen:
                seen.add(j); cyc.append(j); j = tau[j]
            cycles.append(cyc)
    return tau, cycles


def predicted_eta(factors, tau, word, M, m_s):
    return m_s * sum(
        (len(factors[tau[i]]) - 1) * min(word[i], M - word[tau[i]])
        for i in range(len(factors))
    )


def check_family(label, K, n_prime, lambda0, M, k, m_s=1, sample=None, seed=2026):
    n = n_prime * M
    factors = factor_xn_minus_lambda(K, n_prime, lambda0)
    tau, cycles = orbit_data(K, factors, k)
    orbits = sorted((len(c), m_s * (len(factors[c[0]]) - 1)) for c in cycles)
    F = len(factors)
    if sample is None:
        words = itertools.product(range(M + 1), repeat=F)
        total_words = (M + 1) ** F
    else:
        rng = random.Random(seed)
        words = [tuple(rng.randrange(M + 1) for _ in range(F)) for _ in range(sample)]
        total_words = sample

    hist = defaultdict(int)
    for word in words:
        g = [K.one]
        for f, e in zip(factors, word):
            for _ in range(e):
                g = K.poly_mul(g, f)
        kappa = m_s * (n - (len(g) - 1))
        eta_direct = m_s * K.direct_hull_dim(g, n, k)
        eta_pred = predicted_eta(factors, tau, word, M, m_s)
        assert eta_direct == eta_pred, f"{label}: word={word}, direct={eta_direct}, predicted={eta_pred}"
        hist[(kappa, eta_direct)] += 1

    if sample is None:
        expected = trace_dp_global(orbits, M)
        assert dict(hist) == expected, f"{label}: joint histogram mismatch"
        print(f"[PASS exhaustive] {label}: words={total_words}, orbits={orbits}, joint terms={len(hist)}")
    else:
        print(f"[PASS sample]     {label}: sampled words={total_words}, orbits={orbits}")
    return dict(hist), orbits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--quick', action='store_true', help='skip the slowest exhaustive family (F8, n=14)')
    args = ap.parse_args()

    F3 = FiniteField(3, [1, 1])
    F4 = FiniteField(2, [1, 1, 1])
    F8 = FiniteField(2, [1, 1, 0, 1])
    F9 = FiniteField(3, [1, 0, 1])       # x^2 + 1, gen = i
    F16 = FiniteField(2, [1, 1, 0, 0, 1])
    F25 = FiniteField(5, [2, 0, 1])      # x^2 + 2
    F32 = FiniteField(2, [1, 0, 1, 0, 0, 1])

    check_family('F4, n=10 (n\'=5,M=2), lambda=1, k=1', F4, 5, F4.one, 2, 1)
    check_family('F4, n=10 (n\'=5,M=2), lambda0=omega, k=1', F4, 5, F4.gen, 2, 1)
    check_family('F3, n=12 (n\'=4,M=3), lambda=1, k=0', F3, 4, F3.one, 3, 0)
    check_family('F9, n=12 (n\'=4,M=3), lambda0=i, k=1', F9, 4, F9.gen, 3, 1)
    check_family('F9, n=12 (n\'=4,M=3), lambda0=-1, k=1', F9, 4, -F9.one, 3, 1)
    if not args.quick:
        check_family('F8, n=14 (n\'=7,M=2), lambda=1, k=1', F8, 7, F8.one, 2, 1)

    # Mixed algebra F4 x F16 over F4, n=10, lambda=(1,1): componentwise product.
    h1, o1 = check_family('F4 component, n=10, lambda=1, k=1', F4, 5, F4.one, 2, 1, m_s=1)
    h2, o2 = check_family('F16/F4 component, n=10, lambda=1, k=1', F16, 5, F16.one, 2, 1, m_s=2)
    combined = defaultdict(int)
    for (k1, e1), v1 in h1.items():
        for (k2, e2), v2 in h2.items():
            combined[(k1 + k2, e1 + e2)] += v1 * v2
    assert dict(combined) == trace_dp_global(o1 + o2, 2)
    print(f"[PASS exhaustive] F4 x F16, n=10: orbits={o1 + o2}, joint terms={len(combined)}")

    # Larger families: seeded random exponent words, checked one code at a time.
    check_family('F9, n=24 (n\'=8,M=3), lambda=1, k=1', F9, 8, F9.one, 3, 1, sample=60)
    check_family('F25, n=30 (n\'=6,M=5), lambda=1, k=1', F25, 6, F25.one, 5, 1, sample=60)
    check_family('F32, n=62 (n\'=31,M=2), lambda=1, k=1', F32, 31, F32.one, 2, 1, sample=12)
    print('ALL DIRECT FINITE-FIELD CHECKS PASSED')


if __name__ == '__main__':
    main()
