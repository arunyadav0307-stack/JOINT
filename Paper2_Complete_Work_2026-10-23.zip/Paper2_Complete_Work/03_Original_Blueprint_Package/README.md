# Paper 2 Blueprint Package — Repeated-Root Joint Enumerators

This folder is a self-contained research blueprint for the proposed sequel to Paper 1:

**Joint Code-Dimension and $k$-Galois-Hull Enumerators for Repeated-Root Constacyclic Codes over Square-Free Affine Algebras**

## Start here

Read **[BLUEPRINT.md](BLUEPRINT.md)**. It contains, in order:

1. the exact problem and research questions;
2. complete notation and standing assumptions;
3. the repeated-root factorisation and exponent-selection model;
4. $k$-Galois duality, compatibility, and the incompatible case;
5. reciprocal orbits and the $\min$-edge hull formula;
6. the $(M+1)$-state transfer matrix and the main joint-enumerator theorem;
7. LCD invariance, support, closed mean/variance formulas, and extremal-class counts;
8. algorithms, complexity, and the three-layer verification design;
9. computed examples, tables, and figures;
10. draft abstract/highlights, section-by-section manuscript plan, referee-risk register, literature protocol, and a 10-week work plan.

Results are labelled **[READY]**, **[PROOF-TARGET]**, **[COMPUTED]**, or **[CHECK]** so that proved statements, proof plans, computational evidence, and items still requiring a literature/convention check are never confused.

## Reproduce every number and figure

From the workspace root:

```bash
python3 Paper2_RepeatedRoot_Blueprint/code/test_rr_enumerator.py
python3 Paper2_RepeatedRoot_Blueprint/code/generate_tables_figures.py
python3 Paper2_RepeatedRoot_Blueprint/code/verify_rr.py
```

- `code/rr_enumerator.py` — exact transfer-matrix DP, orbit convolution, brute force, moments, extremal counts, support test.
- `code/test_rr_enumerator.py` — internal combinatorial tests (currently all PASS).
- `code/verify_rr.py` — independent generator-matrix/Gram-rank verification over component fields; `--quick` skips the slowest exhaustive family.
- `code/generate_tables_figures.py` — regenerates `tables/*.csv` and `figures/*.png/.pdf`.

## Important mathematical conventions

- $n=n'p^t$, $\gcd(n',p)=1$, $M=p^t$.
- $x^n-\lambda_s=(x^{n'}-\lambda_{s,0})^M$, where $\lambda_{s,0}^M=\lambda_s$.
- A code is an exponent selection $e_f\in\{0,\dots,M\}$ over the distinct irreducible factors.
- On a reciprocal orbit, $\kappa$ gets $w\sum_i(M-e_i)$ and $\eta_k$ gets $w\sum_i\min\{e_i,M-e_{i+1}\}$.
- Dimensions are over $\mathbb F_q$ globally; counting is labeled and $\mathcal A$-linear.

## Current status

- Core enumerator, LCD count, incompatible case, closed mean/variance, and extremal counts: derivations ready at blueprint level.
- One-orbit support trapezoid: bounds have a proof strategy ready; the attainability half is explicitly marked **[PROOF-TARGET]** and computationally verified for $M\le6$, $a\le6$.
- Final literature search and the exact comparison with the affine-algebra hull formula of Debnath et al. remain **[CHECK]** items before submission.
