# Paper 2 Ideas and Roadmap
## Based on Paper 1: *Joint Code-Dimension and $k$-Galois-Hull Enumerators for Simple-Root Constacyclic Codes over Square-Free Affine Algebra Ring*

---

## 1. Paper 1 in one paragraph

Paper 1 works under three restrictions:

1. **Simple-root case:** $\gcd(n,p)=1$, so $x^n-\lambda_s$ is square-free;
2. **Compatible twists:** $\lambda_s^{1+p^{d_s-k}}=1$, so the Frobenius-twisted reciprocal $\tau_{s,k}$ permutes the *same* irreducible factor set;
3. **Labeled counting:** codes are counted as labeled factor selections $J\subseteq\mathcal F_s$, not up to equivalence/isometry.

Its main result is the bivariate enumerator

$$
\mathscr E(u,z)=\sum_C u^{\kappa(C)}z^{\eta_k(C)}
=\prod_s\prod_{O\in\mathcal O_s}\operatorname{tr}\!\left(T_{w_O}(u,z)^{a_O}\right),
\qquad
T_w(u,z)=\begin{pmatrix}u^w&1\\u^wz^w&1\end{pmatrix},
$$

with corollaries for the dimension distribution, hull distribution, LCD count $2^{\sum_s|\mathcal O_s|}$, mean, variance, and conditional moments. The conclusion itself names the two gaps: **repeated-root moduli** and **equivalence classes**.

A good Paper 2 should remove exactly one of these restrictions, reuse the orbit/transfer-matrix machinery, and produce at least one result that is *not* a mechanical corollary of Paper 1.

---

## 2. Ranked ideas at a glance

| Rank | Working title | Novelty | Difficulty | Reuse of Paper 1 code/proofs | Suggested venue | Rough time |
|---|---|---|---|---|---|---|
| **1** | **Repeated-root joint enumerators** ($n=n'p^t$) | High | Medium | Very high | *Finite Fields Appl.*, *Des. Codes Cryptogr.*, *Adv. Math. Commun.* | 6–10 weeks |
| 2 | Joint enumerators **up to multiplier/component equivalence** (weighted Burnside–Pólya) | High | Medium–High | High | *Finite Fields Appl.*, *J. Combin. Des.* | 8–12 weeks |
| 3 | **Simultaneous Galois-hull spectrum** $(\eta_0,\dots,\eta_{e-1})$ — multivariate enumerator | High | High | Medium | *Finite Fields Appl.* | 10–14 weeks |
| 4 | **Asymptotics:** bivariate CLT, local limit, unimodality/monotonicity of the hull distribution | Medium | Low–Medium | Very high | *Adv. Math. Commun.*, *Cryptogr. Commun.* | 4–6 weeks |
| 5 | **BCH/MDS subfamily + EAQECC parameter enumeration** — add minimum distance as third statistic on a nested subfamily | Medium | Medium | Medium | *Quantum Inf. Process.*, *Des. Codes Cryptogr.* | 8–12 weeks |
| 6 | Full **multi-twisted** codes / **non-square-free (chain) affine algebras** | High | Very high | Low | Later paper | 4+ months |

**Recommendation:** Do **#1 as Paper 2**. Fold the exact counts of Galois self-orthogonal / dual-containing / self-dual codes into it (Section 3.5 below). Keep #2 as Paper 3; #4 can become a section of Paper 2 or 3 rather than a standalone paper.

> ⚠️ Before claiming "first" anywhere, run a final novelty check (MathSciNet, zbMATH, arXiv, Scopus) for the exact phrases in Section 8. Debnath et al. (*Discrete Math.* 2026) already treat **individual** codes over affine algebras (generators, one-code hull formula, LCD criterion, EAQECCs), and Debnath–Prakash (2025) already treat **average** hull dimensions. The population-level **joint distribution in the repeated-root case** is the open slot.

---

## 3. Recommended Paper 2 — Repeated-root joint enumerators

### 3.1 Proposed title

> **Joint Code-Dimension and $k$-Galois-Hull Enumerators for Repeated-Root Constacyclic Codes over Square-Free Affine Algebras**

### 3.2 Why this is the natural sequel

- Paper 1's conclusion explicitly excludes repeated roots — a referee of Paper 2 will immediately see the gap being closed.
- The binary selection $\{0,1\}$ becomes an **exponent vector** $\{0,\dots,M\}$, so the combinatorics genuinely changes: a $2\times2$ transfer matrix becomes an $(M+1)\times(M+1)$ transfer matrix, and the hull statistic $u_i(1-u_{i+1})$ becomes a $\min$-statistic. This is a real generalization, not a re-proof.
- All Paper 1 infrastructure survives: CRT decomposition of $\mathcal A$, reciprocal orbits, weights $w_O=m_sd_O$, conditional moments via $\partial_z$, and the verification suite (`verify_all.py`) needs only `bits ∈ {0,1}` → `exponents ∈ {0,...,M}`.

### 3.3 Setup

Let $n=n'p^t$ with $\gcd(n',p)=1$, $t\ge1$, and put $M=p^t$. Over each component $K_s=\mathbb F_{p^{d_s}}$, write $\lambda_s=\lambda_{s,0}^{M}$ (unique $\lambda_{s,0}$, since $a\mapsto a^{M}$ is a bijection of $K_s^*$). Then

$$
x^n-\lambda_s=\bigl(x^{n'}-\lambda_{s,0}\bigr)^{M}
=\prod_{f\in\mathcal F_s} f(x)^{M},
$$

where $\mathcal F_s$ is the (square-free) irreducible factor set of $x^{n'}-\lambda_{s,0}$. Every $\lambda_s$-constacyclic code is $\langle g\rangle$ with

$$
g(x)=\prod_{f\in\mathcal F_s} f(x)^{u_f},\qquad 0\le u_f\le M,
$$

so a code is an **exponent selection** $u:\mathcal F_s\to\{0,\dots,M\}$, and the total number of labeled codes is $(M+1)^{\sum_s|\mathcal F_s|}$.

Impose compatibility on $\lambda_{s,0}$ so that $\tau_{s,k}$ permutes $\mathcal F_s$ exactly as in Paper 1.

### 3.4 Expected main theorem (to be proved)

For an orbit $O=(f_1,\dots,f_{a})$ under $\tau_{s,k}$ with weight $w=m_sd_O$ and exponent word $(u_1,\dots,u_a)$:

- **Code-dimension contribution:** $\;w\sum_i (M-u_i)$;
- **Hull-dimension contribution:** $\;w\sum_i \min\{\,u_i,\;M-u_{i+1}\,\}$ (indices mod $a$),

because the hull generator is $\operatorname{lcm}(g,g^{\text{dual}})$, whose exponent at $f_{i+1}$ is $\max\{u_{i+1},\,M-u_i\}$, and $M-\max\{u_{i+1},M-u_i\}=\min\{u_i,M-u_{i+1}\}$.

Define the $(M+1)\times(M+1)$ transfer matrix, for source state $\alpha$ and destination state $\beta\in\{0,\dots,M\}$,

$$
\bigl(T^{(M)}_w(u,z)\bigr)_{\alpha,\beta}
= u^{\,w(M-\beta)}\; z^{\,w\min\{\alpha,\,M-\beta\}}.
$$

**Main theorem (target statement):**

$$
\mathscr E^{(M)}(u,z)
=\sum_C u^{\kappa(C)}z^{\eta_k(C)}
=\prod_s\prod_{O\in\mathcal O_s}
\operatorname{tr}\!\Bigl(\bigl(T^{(M)}_{w_O}(u,z)\bigr)^{a_O}\Bigr).
$$

Sanity check: at $M=1$, $\min\{u_i,1-u_{i+1}\}=u_i(1-u_{i+1})$ and $T^{(1)}_w=T_w$ — Paper 1 is recovered exactly. State this as a corollary ("consistency with the simple-root case").

### 3.5 Corollaries that make the paper rich

1. **Marginals:** $\mathscr E^{(M)}(u,1)=\prod_{s,f}\bigl(1+u^{w_f}+\dots+u^{Mw_f}\bigr)$; hull polynomial $\mathscr H^{(M)}(z)=\mathscr E^{(M)}(1,z)$.
2. **LCD count (surprising invariance):** $\eta_k=0 \iff$ every edge has $\min\{u_i,M-u_{i+1}\}=0$. On a cycle this forces the word to be **constant** ($0\dots0$ or $M\dots M$): if some $0<u_i<M$, then $u_{i+1}=M$, hence all successors are $M$, contradicting the incoming edge unless the word is constant. Hence
   $$\#\{\text{$k$-Galois LCD codes}\}=2^{\sum_s|\mathcal O_s|},$$
   *independent of $M$* — a clean headline result. (Handle $a_O=1$ separately: $\min\{u,M-u\}=0\iff u\in\{0,M\}$.)
3. **Mean:** with $U,V$ i.i.d. uniform on $\{0,\dots,M\}$,
   $\mathbb E[\min\{U,M-V\}]=\frac{1}{(M+1)^2}\sum_{j=1}^{M}j^2=\frac{M(2M+1)}{6(M+1)}$,
   so $\mathbb E[\eta_k]=\frac{M(2M+1)}{6(M+1)}\sum_{s,O} a_Ow_O$ (no $a_O\ge2$ restriction needed now — length-1 orbits *do* contribute when $M\ge2$; this is a visible difference from Paper 1).
   At $M=1$: $\frac{1\cdot3}{6\cdot2}=\frac14$. ✓
4. **Variance:** computable from $\operatorname{Var}$ and adjacent-edge covariance of $\min\{U_i,M-U_{i+1}\}$ (closed form in $M$ via power sums $\sum j^2,\sum j^3,\sum j^4$). More work than Paper 1 — good, it shows depth.
5. **Self-orthogonal / dual-containing / self-dual counts** (new section, not in Paper 1):
   - $C\subseteq D_k(C) \iff u_{i}+u_{i-1}\ge M$ on every edge; count via trace of the 0–1 submatrix of allowed transitions.
   - $D_k(C)\subseteq C \iff u_i+u_{i-1}\le M$ everywhere.
   - Self-dual $\iff u_i+u_{i-1}=M$ everywhere $\iff$ the word alternates $(\alpha,M-\alpha,\alpha,\dots)$: possible iff $a_O$ is even (any $\alpha$) or $M$ even with $\alpha=M/2$. This gives exact existence/count criteria per orbit — very quotable.
6. **Incompatible twists:** if compatibility fails for $\lambda_{s,0}$, the two moduli are coprime and the hull is again trivial (same argument as Paper 1, Remark on incompatible twists), so the paper covers **all** $\lambda$.
7. **Algorithm/complexity:** DP over $(M+1)$ states; arithmetic cost $O\!\bigl((M+1)^2 N_F (W+1)(\lfloor W/2\rfloor+1)\bigr)$ with $W=n\sum_s m_s$ — state the analogue of Paper 1's Proposition on exact computation.

### 3.6 Pilot computational evidence (already run on 23 Oct 2026)

Using Paper 1's own `verify_all.py` finite-field routines, the formula $\eta_k=\sum_i \deg(f_{\tau(i)})\min\{u_i,M-u_{\tau(i)}\}$ was checked against the direct Gram-matrix hull computation for **every** exponent selection in three families:

| Family | $n'$ | $M$ | $n$ | Selections checked | Mismatches | LCD count | Predicted $2^{\#\text{orbits}}$ |
|---|---|---|---|---|---|---|---|
| $\mathbb F_4$, $\lambda=1$, $k=1$ | 5 | 2 | 10 | $3^3=27$ | 0 | — | — |
| $\mathbb F_3$, $\lambda=1$, $k=0$ | 4 | 3 | 12 | $4^3=64$ | 0 | 8 | $2^3=8$ ✓ |
| $\mathbb F_8$, $\lambda=1$, $k=1$ | 7 | 2 | 14 | $3^7=2187$ | 0 | 4 | $2^2=4$ ✓ |

This is strong evidence the main theorem is correct as stated; the remaining work is the proof and exposition.

### 3.7 Proposed examples table for the paper

Reuse Paper 1's families with a $p$-power multiplier so readers can compare directly:

- $\mathbb F_4$, $n=10$ ($n'=5$, $M=2$): full joint table, brute-force verified.
- $\mathbb F_8$, $n=14$ ($n'=7$, $M=2$): orbits $(1,1),(6,1)$ as in Paper 1 Example 5.2, now $3^7$ codes — show how the hull support "fills in" (e.g. $\eta$ values impossible at $M=1$ appear).
- $\mathbb F_4\times\mathbb F_{16}$, $n=10$: mixed-weight example (analogue of Paper 1 Example 5.3).
- **Big example:** $\mathbb F_{32}$, $n=62$ ($n'=31$, $M=2$): orbits $(1,1),(10,1)^3$ as in Paper 1 Example 5.4, total $3^{31}\approx6.2\times10^{14}$ codes counted exactly by the DP — the natural "impossible by enumeration" showcase.
- Characteristic 3 and 5 rows (e.g. $\mathbb F_9$, $n=12$; $\mathbb F_{25}$, $n=30$) for the same reason as Paper 1 (signs/normalizations invisible in characteristic 2).

### 3.8 Pitfalls to handle carefully

1. **Dual twist in repeated-root case:** prove the $k$-Galois dual generator is still $h^{\#_{s,k}}$ with $h=(x^n-\lambda_s)/g$ — the Euclidean step (Paper 1, Lemma on ordinary reciprocal) does not need square-freeness, but re-verify the degree/dimension argument.
2. **Compatibility condition must be stated for $\lambda_{s,0}$**, and related back to $\lambda_s$: $\lambda_{s,0}^{1+p^{d_s-k}}=1 \iff \lambda_s^{(1+p^{d_s-k})/\gcd(\cdot)}$ — derive the clean equivalent form; don't hand-wave.
3. **Code-first vs candidate-first pairing:** keep Paper 1's convention and remark; the Gram-rank hull-dimension equality still applies.
4. **$M$ is the same for all components** ($M=p^t$ depends only on $n$ and $p$) — state this explicitly; component variation enters only through $w_O$.
5. **Length-1 orbits now contribute to the hull** ($\min\{u,M-u\}>0$ for $0<u<M$) — flag this prominently; it changes the mean/variance and kills the "$a_O=1$ contributes 0" intuition from Paper 1.
6. Compare with Debnath et al. (affine algebras, 2026), whose hull formula uses $\max\{u_i,p^{e'}-u_{i-1}\}$-type terms for **one code** under extra coprimality hypotheses — show your $\min$-form agrees where they overlap and that you need **no** condition $\gcd(\operatorname{ord}\lambda_s,n')=1$.

---

## 4. Idea 2 — Counting up to equivalence (weighted Burnside–Pólya)

**Title:** *Joint enumerators of constacyclic codes over affine algebras up to multiplier and component-permutation equivalence.*

**Key observation:** Paper 1 counts labeled selections. Let a finite group $G$ permute the factor set $\bigsqcup_s\mathcal F_s$ such that every $\gamma\in G$ (i) preserves weights $w$, and (ii) **commutes with $\tau_{s,k}$**. Admissible multipliers $\alpha\mapsto\alpha^t$ (with $\lambda_s^t=\lambda_s$ on roots), Frobenius permutations of factors, and permutations of isomorphic components with matching $(\lambda_s,m_s)$ are the natural examples; each $\gamma$ preserves $(\kappa,\eta_k)$, so $G$ acts on codes with fixed joint parameters.

**Expected formula:** a selection fixed by $\gamma$ is constant on $\gamma$-cycles; since $\gamma\tau=\tau\gamma$, $\tau$ permutes the $\gamma$-cycles, and on a $\tau$-orbit of $\gamma$-cycles of length $a'$ with block size $b$, the effective weight is $bw$. Hence the fixed enumerator is again a product of traces, and Burnside gives

$$
\mathscr E_G(u,z)=\frac1{|G|}\sum_{\gamma\in G}\;
\prod_{\text{$\tau$-orbits of $\gamma$-cycles}}
\operatorname{tr}\!\left(T_{bw}(u,z)^{a'}\right),
$$

whose coefficient of $u^\kappa z^\eta$ is the number of $G$-equivalence classes with those parameters. Showcase: $\mathbb F_{32}$, $n=31$ with the full multiplier group $(\mathbb Z/31\mathbb Z)^*$ — count inequivalent cyclic codes by $(\kappa,\eta_1)$ without listing $2^{31}$ codes.

**Caveats:** be precise that this is multiplier/component equivalence, *not* full monomial equivalence; check classical literature on inequivalent cyclic codes before claiming novelty for the $\eta$-free specialization.

---

## 5. Idea 3 — Simultaneous Galois-hull spectrum

**Title:** *The simultaneous Galois-hull spectrum of constacyclic codes over affine algebras: a multivariate enumerator.*

For each $k\in\{0,\dots,e-1\}$ the same code has a hull dimension $\eta_k$. Paper 1 treats one $k$ at a time. Ask instead for the **joint** distribution of the vector $(\kappa,\eta_0,\dots,\eta_{e-1})$: how many codes are simultaneously Euclidean-LCD and Hermitian-LCD? What is $\operatorname{Cov}(\eta_k,\eta_{k'})$?

On roots, $\tau_k$ acts as $\alpha\mapsto\alpha^{-p^{d-k}}$; the maps for different $k$ differ by Frobenius powers, so the relevant permutation group on a root-exponent set $\mathbb Z/N$ is generated by $j\mapsto -p^k j$ — an affine/dihedral-type action. A selection word must be read simultaneously along several step-maps, turning the transfer matrix into a finite-state machine with memory (or a tensor-network trace on the combined orbit graph). Feasible, original, but the hardest of the three main options — best as Paper 3/4, possibly first for a single field ($N=1$ component) before the affine-algebra case.

---

## 6. Idea 4 — Asymptotics of the hull distribution

Paper 1 gives exact mean and variance. Natural completions:

- **Bivariate CLT / local limit theorem** for $(\kappa,\eta_k)$ as the number of orbits $\to\infty$ (independent, non-identical orbit contributions; Lindeberg condition in terms of $\max w_O$ vs. total variance; lattice span $=\gcd$ of weights).
- **Covariance** $\operatorname{Cov}(\kappa,\eta_k)$ per orbit in closed form; asymptotic conditional law of $\eta_k$ given $\kappa \approx n/2\cdot\sum m_s$.
- **Unimodality/log-concavity:** for one orbit, $r\mapsto 2\binom{a}{2r}$ — investigate when the hull polynomial's coefficients are log-concave (homogeneous weights) and give counterexamples with mixed weights (gaps from different $w_O$). Compare with the 2026 monotonicity results for *unrestricted* linear codes.

Verdict: solid mathematics, but as a standalone paper it may be judged a corollary of Paper 1. **Best used as a final section of Paper 2** (with $M$ general, the CLT statement covers both papers at once).

---

## 7. Idea 5 — Add distance: BCH/MDS subfamily and EAQECC parameters

Minimum distance is **not** additive over orbits, so a trivariate enumerator over *all* selections is out of reach. But on the **nested BCH subfamily** (generator roots = consecutive powers $\alpha^b,\dots,\alpha^{b+\delta-2}$), the selection set is an interval in root-exponent space, $\kappa$ and designed distance $\delta$ are known, and $\eta_k$ reduces to counting $|\tau(J)\setminus J|$-type boundary points of an interval under $j\mapsto -p^{d-k}j$. One can then enumerate all attainable triples $(\kappa,\eta_k,\delta)$ and convert them into EAQECC parameters $[[n,\,\kappa-\eta_k,\,d;\,n-\kappa-\eta_k]]$ (with the alphabet/hull-type care that this conversion requires).

**Risks:** Debnath et al. already have an EAQECC section over affine algebras, and MDS-with-prescribed-Galois-hull constructions exist over fields (Cao 2021 and successors). This idea only works if you can certify *new or optimal* parameters (check against EAQECC tables) — do the parameter search computationally **before** committing.

**Idea 6 (defer):** all multi-twisted codes over $\mathcal A$ (counting subspaces in CRT components $\mathbb F^\ell$ with $q$-binomial weights — the population analogue of Taki Eldin–Solé's generator-matrix results), and non-square-free $\mathcal A$ (products of chain rings, Hensel lifting, torsion codes). Both are strong but require substantial new structure theory; not a quick Paper 2.

---

## 8. Literature checklist before writing

Search these exact strings (MathSciNet / zbMATH / arXiv / Google Scholar) and record the closest hits in the introduction's comparison paragraph:

- "repeated-root" + "Galois hull" + "number of" / "enumeration"
- "joint distribution" / "bivariate" + "hull dimension" + "constacyclic"
- "affine algebra" + "constacyclic" + "hull" + "count"
- "transfer matrix" + "hull" + "constacyclic codes"
- For Idea 2: "inequivalent cyclic codes" + "multiplier" + "enumeration"; "Pólya" + "cyclic codes"

Closest known neighbours to position against (from Paper 1's bibliography and a quick web check): Debnath et al., *Galois hulls of constacyclic codes over affine algebra rings*, Discrete Math. 2026 (one-code formulas + EAQECC); Debnath–Prakash, *Average dimensions of Galois hulls of constacyclic codes*, AMC 2025 (first moments only, incl. the ring $\mathbb F_q[u]/\langle u^m-u\rangle$); Debnath et al., *Study of small Galois hull dimensions*, AMC 2026 (which small values occur); Sangwisut et al. 2015 and Debnath et al. 2023 (prescribed-hull counts over fields, simple-root).

---

## 9. Suggested 8-week plan for Paper 2 (Idea 1)

| Week | Task |
|---|---|
| 1 | Literature checklist (Sec. 8); fix notation $n=n'p^t$, $M=p^t$, $\lambda_{s,0}$; derive the clean compatibility condition. |
| 2 | Prove the dual-generator theorem in the repeated-root case; derive the $\min$-formula for $\eta_k$ via the lcm bridge. |
| 3 | Transfer matrix $T^{(M)}_w$, trace identity, main theorem; $M=1$ recovery of Paper 1. |
| 4 | Corollaries: marginals, LCD invariance, mean. Start variance computation. |
| 5 | Self-orthogonal / dual-containing / self-dual counts (transition-submatrix traces; alternating-word criterion). |
| 6 | Extend `verify_all.py`: exponent selections, $(M+1)$-state DP vs. direct Gram-matrix hulls; run $\mathbb F_4/\mathbb F_8/\mathbb F_3/\mathbb F_9/\mathbb F_{25}$ families. |
| 7 | Big example $\mathbb F_{32}$, $n=62$ ($3^{31}$ codes); tables/figures; complexity proposition. |
| 8 | Introduction with comparison paragraph, abstract, highlights; internal read-through for the pitfalls in Sec. 3.8. |

---

*Prepared 23 October 2026 from Paper 1 (`main.tex`, `references.bib`, `code/verify_all.py`) plus a pilot recomputation of the repeated-root hull formula.*
