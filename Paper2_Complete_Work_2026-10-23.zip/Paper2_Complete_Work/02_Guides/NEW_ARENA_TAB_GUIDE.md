# Paper 2 ko New Arena Tab / New Chat me Chalane ki Guide

## Pehle ye samjho — 3 zaroori baatein

1. **Sirf browser ka new tab kholne se naya workspace nahi milega.** Aapko Arena me **New Chat / New Conversation** start karni hogi. Nayi conversation ka workspace khaali hota hai — isiliye Paper 2 ka Git repo wahan dobara laana padega.
2. **Arena me GitHub app-connector abhi available nahi hai.** Maine is environment me check kiya hai — GitHub connector `unsupported` aa raha hai. Isliye "Apps me GitHub connect karo" wala rasta abhi kaam nahi karega. Iska matlab ye nahi ki Git use nahi ho sakta — Arena ka agent `git` command chala sakta hai, bas repo ko nayi chat tak **bundle/ZIP ya public link** se pahunchana hoga.
3. **Sabse safe aur pakka tareeka = Bundle method (Route 1).** Repo private bhi rahega, Git history bhi preserve rahegi, aur kisi login/token ki zaroorat nahi padegi.

---

## Route 1 (Recommended) — Private repo + Bundle upload

### Step 1 — Isi (purani) chat se 1 file download karo

Workspace se ye file download karo:

```text
Paper2_Manuscript.bundle
```

Isme poora Paper 2 project aur pehla Git commit `dc5f28a` hai.

> Agar bundle attach karne me problem aaye to dusri file use karna: `Paper2_Manuscript_GitHub_Upload.zip`.

### Step 2 — (Agar abhi tak nahi kiya) GitHub par private repo me push karo

Ye step sirf backup ke liye hai; new Arena tab ke liye bundle hi kaafi hai. Details `GITHUB_PUSH_INSTRUCTIONS.md` me hain. Short me:

```bash
git clone Paper2_Manuscript.bundle Paper2-Repeated-Root
cd Paper2-Repeated-Root
git remote add origin https://github.com/arunyadav0307-stack/Paper2-Repeated-Root.git
git push -u origin main
```

(GitHub par pehle **empty private** repo bana lena — README/.gitignore add mat karna.)

### Step 3 — Arena me New Chat kholo

- Arena me **New Chat / New Conversation** start karo.
- Mode **Agent Mode** hi select rakhna (taaki agent files bana sake, code chala sake).

### Step 4 — Bundle attach karo

Chat ke attachment/upload (paperclip) button se `Paper2_Manuscript.bundle` attach karo.

- Agar `.bundle` file attach na ho, to `Paper2_Manuscript_GitHub_Upload.zip` attach karo — agent use unzip kar lega.

### Step 5 — Neeche wala Starter Prompt copy-paste kar do

Ye prompt naye agent ko pura context de dega. **Bracket wala hissa apne case ke hisaab se rakho:**

```text
Ye mera Paper 2 project hai. Maine Git bundle attach kiya hai
(agar ZIP attach kiya hai to wahi use karo). Tumhe is project ko
end-to-end handle karna hai. Pehle ye karo, phir kaam shuru karo:

1. Bundle ko restore karo:
   git clone Paper2_Manuscript.bundle Paper2_Manuscript
   (ZIP hai to unzip karke usi folder ko repo banao.)
   Phir git log --oneline -1 se confirm karo ki pehla commit
   dc5f28a "Initialize Paper 2 repeated-root manuscript project" hai.

2. README.md, PROJECT_STATUS.md aur docs/BLUEPRINT.md pura padho.
   Blueprint hi final authority hai. Agar kahin purana roadmap mile
   to use ignore karo — wo superseded hai.

3. Code verify karo:
   python3 code/test_rr_enumerator.py
   python3 code/verify_rr.py --quick
   Dono PASS hone chahiye. Result mujhe confirm karo.

4. Current status ye hai:
   - Phase 0 (blueprint, code, figures, tables) COMPLETE hai.
   - Ab Phase 1 shuru karna hai: manuscript/main.tex me
     "The repeated-root setting" aur "k-Galois duality" sections
     ke full formal proofs likhne hain (factorisation lemma,
     exponent-selection bijection, Euclidean dual bina
     square-freeness ke, dual generator, compatibility condition,
     incompatible case).

5. Niyam (inhe mat todna):
   - Koi bhi [PROOF-TARGET] wala result theorem claim mat karo
     jab tak proof complete na ho (khaas taur par support
     trapezoid ki attainability).
   - Har example me lambda_{s,0} aur lambda_s = lambda_{s,0}^M
     dono likho.
   - a_O = 1 orbit ke mean/variance alag formulas se check karo.
   - Har number script se regenerate hona chahiye, haath se type
     kiya number nahi chalega.
   - Phase complete hone par PROJECT_STATUS.md update karo aur
     git commit banao.

6. Default assumptions: authors aur affiliations Paper 1 wale hi
   hain, target journal Finite Fields and Their Applications hai.
   Inme change main baad me bataunga.

Pehle Step 1–3 karke mujhe short me confirm karo: commit hash,
total files, tests ka result, aur current phase. Phir bina ruke
Phase 1 ka drafting shuru kar do.
```

### Step 6 — Naya agent sahi chala ya nahi, kaise pehchano

Naye agent ka pehla jawab kuch is prakar hona chahiye:

- Commit: `dc5f28a` confirm kare;
- 49 tracked files bataye;
- `test_rr_enumerator.py` ke 7 test groups PASS bataye;
- `verify_rr.py --quick` PASS bataye;
- Bole ki current phase = **Phase 1 (Setting + Duality)**.

Agar agent kuch aur bole (jaise purana roadmap uthale, ya seedha abstract likhne lage), to use bolo: *"Nahi, pehle PROJECT_STATUS.md padho aur wahi se continue karo."*

### Step 7 — Nayi chat ka kaam wapas GitHub par kaise jayega

Arena ka agent GitHub par direct push nahi kar sakta (uske paas aapka login nahi hai — aur password/token chat me **kabhi mat dena**). Isliye jab nayi chat me ek phase complete ho jaye, to agent se bolo:

```text
Ab is phase ka kaam commit karke ek Git bundle banao:
git bundle create Paper2_Phase1.bundle main
aur bundle file mujhe download ke liye do.
```

Phir apne computer par, local repo me:

```bash
git fetch /path/to/Paper2_Phase1.bundle main:refs/heads/arena-phase1
git switch main
git merge --ff-only arena-phase1
git push
```

Agar `--ff-only` fail ho (matlab dono taraf alag-alag changes ho gaye hain), to force mat karo — pehle `git log arena-phase1` dekh kar samjho, ya mujhse (isi chat me) poochho.

---

## Route 2 — Agar repo PUBLIC kar diya hai to sirf link se

Agar aapne repo public kar diya hai (ya karne ka faisla kiya hai), to attach karne ki zaroorat nahi:

1. New Chat kholo (Agent Mode).
2. Starter Prompt me pehli line badal kar repo ka link de do:

```text
Ye mera Paper 2 project hai. Repo:
https://github.com/arunyadav0307-stack/Paper2-Repeated-Root
Pehle git clone karo, phir README.md, PROJECT_STATUS.md aur
docs/BLUEPRINT.md padho...
```

(Baaki prompt Route 1 wala hi rakho.)

**Dhyaan do:** public repo se agent *padh* (clone) sakta hai, lekin *push* phir bhi nahi kar sakta. Wapas bhejne ke liye Step 7 wala bundle method hi lagega. Aur unpublished paper ko public karna hai ya nahi — ye faisla authors ka hai; meri salah abhi **private** rakhne ki hai.

---

## Route 3 — Agar Arena UI me kabhi GitHub connector dikhai de

Agar aapke Arena interface me kahin **Apps / Connectors** section me GitHub ka option dikhe (ho sakta hai future me aa jaye), to aam taur par steps aise hote hain:

1. Settings/Profile → Connected Apps → GitHub → Connect;
2. GitHub par login karke Arena ko authorize karo, sirf Paper 2 wale repo tak access do;
3. New Chat me us app ko ON karo;
4. Agent se bolo repo padhe.

**Lekin abhi ki sthiti ye hai:** maine check kiya hai aur is Arena environment me GitHub connector `unsupported` hai. Isliye agar option na dikhe to samay barbaad mat karo — **Route 1 hi follow karo**, wo har haal me chalega.

---

## Common problems aur unka hal

| Problem | Hal |
|---|---|
| Nayi chat me purani files dikhai de rahi hain | Aapne new browser tab khola hai, new conversation nahi. Arena me **New Chat** start karo. |
| `.bundle` attach nahi ho raha | `Paper2_Manuscript_GitHub_Upload.zip` attach karo; prompt me "unzip karke repo banao" likha hi hai. |
| Agent private repo clone nahi kar pa raha (404/auth error) | Ye expected hai — agent ke paas aapka GitHub access nahi. Bundle method (Route 1) use karo. |
| Agent purana roadmap utha raha hai | Bolo: *"`docs/BLUEPRINT.md` hi authority hai, roadmap superseded hai."* |
| Agent seedha theorem claim kar raha hai bina proof ke | Bolo: *"[PROOF-TARGET] wale results tab tak conjecture/target rakho jab tak proof draft me complete na ho."* |
| Tests fail ho rahe hain | Agent se bolo exact error dikhaye; `code/` ke andar se nahi, repo root se command chalaye: `python3 code/test_rr_enumerator.py` |
| GitHub connector UI me nahi mil raha | Wo abhi unsupported hai. Route 1 follow karo. |

---

## Ek nazar me poora flow

```text
Purani chat (ye wali)
   └── Paper2_Manuscript.bundle  ──download──►  aapka computer
                                                    │
                          (backup) git push ────────┤──► GitHub private repo
                                                    │
                          attach bundle ────────────┘
                                                    ▼
                              New Arena Chat (Agent Mode)
                              + Starter Prompt paste karo
                                                    │
                              Agent: restore → padhai → tests
                                                    ▼
                              Phase 1, 2, 3 ... ka kaam
                                                    │
                              Phase complete → naya bundle
                                                    ▼
                              aapke computer par fetch/merge
                                                    ▼
                              git push → GitHub up to date
```
