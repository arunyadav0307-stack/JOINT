# Elsevier `elsarticle` manuscript package

This package contains the manuscript **“Joint Code-Dimension and *k*-Galois-Hull Enumerators for Simple-Root Constacyclic Codes over Square-Free Affine Algebras”**, prepared in Elsevier's `elsarticle` format for *Finite Fields and Their Applications*.

The source uses the numeric Elsevier bibliography style and includes the class and bibliography-style files needed to build it. The bundled `elsarticle.cls` is version 3.5 (2026/01/09).

## Files

- `main.tex` — manuscript source in the `elsarticle` class.
- `main.pdf` — compiled manuscript.
- `main.bbl`, `references.bib` — generated bibliography and BibTeX database.
- `highlights.txt` — draft article highlights (separate editable file).
- `elsarticle.cls`, `elsarticle-num.bst` — Elsevier class and numeric reference style.
- `fig_galois_hull.png` — manuscript figure.
- `code/`, `tables/` — computational verification scripts and exact result tables from the original package.

## Compile

Run these commands from this directory:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

A LaTeX installation with the packages used by `elsarticle` (including AMS math, TikZ/PGF, `tabularx`, and `microtype`) is required. A double-spaced review copy can be produced, if required by the journal or submission system, by changing the class line to `\documentclass[preprint,review,12pt]{elsarticle}`.

## Conversion notes

The manuscript's mathematical text, tables, citations, and reproducibility files have been carried over. The article-class layout was replaced with Elsevier front matter, `elsarticle` numeric references, and journal-standard float placement. The workflow figure now has a caption and label so its in-text reference resolves. The author list and corresponding-author email have been updated from author-provided details. Postal-address, author-contribution, and competing-interest fields marked `TBD` or `DUMMY` must be completed or confirmed by the authors before submission. The AI-use statement follows the author's requested generic wording; check it against the current journal guide before submission, which gives an example naming the tool/service.
