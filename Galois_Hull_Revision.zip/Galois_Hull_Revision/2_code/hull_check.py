"""Direct k-Galois hull check vs. orbit boundary statistic (one component, m_s = 1).
Usage: python hull_check.py   (requires: pip install galois numpy)"""
import itertools, numpy as np, galois

def rho(a, p, d, k):                      # inverse Frobenius a -> a^(p^(d-k))
    return a ** (p ** ((d - k) % d))

def recip(f, GF, p, d, k):                # normalized inverse-Frobenius reciprocal, eq. (5)
    c = f.coeffs[::-1]                    # ascending f_0..f_r
    r = rho(c, p, d, k)
    return galois.Poly(r / r[0], field=GF)  # descending coeffs = rho(f_i) x^(r-i), normalized

def check(q, n, lam, k, sample=None, seed=0):
    GF = galois.GF(q); p, d = GF.characteristic, GF.degree
    lam = GF(lam); M = galois.Poly.Degrees([n, 0], [1, -lam], field=GF)
    F = list(M.factors()[0])
    tau = [F.index(recip(f, GF, p, d, k)) for f in F]   # fails if twist incompatible
    if sample:
        rng = np.random.default_rng(seed)
        subsets = [tuple(rng.integers(0, 2, len(F))) for _ in range(sample)]
    else:
        subsets = list(itertools.product([0, 1], repeat=len(F)))
    bad = 0
    for eps in subsets:
        g = galois.Poly.One(GF)
        for e, f in zip(eps, F):
            if e: g *= f
        dimC = n - g.degree
        if dimC == 0: pred = direct = 0
        else:
            B = GF(np.zeros((dimC, n), dtype=int))
            for i in range(dimC):
                row = (g * galois.Poly.Degrees([i], field=GF)) % M
                c = row.coeffs[::-1]; B[i, :len(c)] = c
            D = rho(B.null_space(), p, d, k)             # code-first dual = rho(C^perp_E)
            dimD = D.shape[0]
            both = np.vstack([B, D]) if dimD else B
            direct = dimC + dimD - np.linalg.matrix_rank(both)
            # hull support: f_i unselected with tau^{-1}(f_i) selected
            pred = sum(F[j].degree for j in range(len(F))
                       if eps[j] == 0 and eps[tau.index(j)] == 1)
        bad += (pred != direct)
    return len(subsets), bad

if __name__ == "__main__":
    GF9 = galois.GF(9); i9 = [x for x in GF9.elements if x**2 == GF9(-1 % 3)][0]
    cases = [(3, 4, 1, 0), (3, 4, 2, 0), (9, 4, 1, 1), (9, 4, int(i9), 1), (9, 4, 2, 1),
             (9, 8, 1, 1), (25, 6, 1, 1)]
    for c in cases: print(c, check(*c))
    print((32, 31, 1, 1), check(32, 31, 1, 1, sample=150))
