import re, sys
SRC = '/home/user/src/submission/manuscript/main_original.tex'
DST = '/home/user/src/submission/manuscript/main.tex'
t = open(SRC).read()
log = []

def rep(old, new, tag, count=1):
    global t
    n = t.count(old)
    if n != count:
        sys.exit(f'[{tag}] expected {count} match(es), found {n}: {old[:70]!r}')
    t = t.replace(old, new)
    log.append(tag)

def span(start, end, new, tag):
    """replace from `start` through `end` (inclusive); both unique."""
    global t
    i = t.find(start)
    if i < 0 or t.count(start) != 1:
        sys.exit(f'[{tag}] start not unique/found: {start[:70]!r}')
    j = t.find(end, i)
    if j < 0:
        sys.exit(f'[{tag}] end not found: {end[:70]!r}')
    t = t[:i] + new + t[j + len(end):]
    log.append(tag)

# ------------------------------------------------------------ preamble
rep(r'\usepackage{array}', r'\usepackage{array}' + '\n' + r'\usepackage{tabularx}', 'P0 tabularx')
rep(r'\newcommand{\CF}{\mathrm{code\text{-}first}}' + '\n' + r'\newcommand{\Candidate}{\mathrm{candidate\text{-}first}}',
    r'\newcommand{\Dk}{D_k}', 'P0 macros')

# ------------------------------------------------------------ S1 abstract
span(r'Given a square-free affine algebra over $\F_q$, how many',
     r'repeated roots and incompatible twists are excluded.',
r'''This paper counts the simple-root constacyclic codes over square-free affine algebras over a finite field, sorted jointly by code dimension and by the dimension of the Galois hull. Every such code is a product of component ideals determined by a labeled choice of irreducible factors. When the twist satisfies a compatibility condition, a Frobenius-twisted reciprocal permutes these factors, and the hull dimension becomes a weighted count of boundaries in the selection pattern along each orbit of this permutation. A two-state transfer matrix, or an equivalent closed formula, turns these orbit counts into a bivariate generating polynomial whose coefficients are exactly the numbers of codes with each pair of code dimension and hull dimension. The polynomial gives the dimension distributions, the number of codes with complementary duals, and the conditional mean and variance of the hull dimension at each code dimension, and a dynamic program computes it from the orbit data. Direct linear-algebra checks in characteristics two, three and five, and an exact computation for length-31 codes over the field with 32 elements, agree with the formulas. The results are useful for selecting constacyclic codes with a prescribed hull dimension, for example complementary-dual codes and codes used in hull-based constructions.''', 'S1 abstract')

# ------------------------------------------------------------ Introduction
span(r'The question addressed here is a counting question:',
     r'or code equivalence is taken.' + '\n\nJoint',
r'''The question addressed here is a counting question: for constacyclic codes over a fixed square-free affine algebra, how many labeled codes (in the sense of Section~\ref{sec:selections}) realize each ordered pair $(\kappa,\eta)$ of code dimension and $k$-Galois-hull dimension?

Joint''', 'P2')
rep(r'including fixed-dimension counts, were treated through reciprocal factors \cite{sangwisut2015},',
    r'including fixed-dimension counts, were treated through reciprocal factors \cite{sangwisut2015},% [UNVERIFIED - author must check against the published version]' + '\n',
    'P3 flag')
rep(r'restricted prescribed-dimension counts were reported together with a correction \cite{debnathConstacyclic2023,debnathCorrection2023}.',
    r'restricted prescribed-dimension counts were reported together with a correction \cite{debnathConstacyclic2023,debnathCorrection2023}.% [UNVERIFIED - author must check against the published version]' + '\n',
    'P4 flag a')
rep(r'including, in stated cases, the number of attainable hull-dimension values.',
    r'including, in stated cases, the number of attainable hull-dimension values.% [UNVERIFIED - author must check against the published version]' + '\n',
    'P4 flag b')
span(r'A hull-dimension formula for a specified code --- or even',
     r'The answer is an exact product over reciprocal-factor orbits.',
r'''A hull-dimension formula for a specified code, or even the number of attainable hull-dimension values, does not determine the \emph{number of codes} realizing each ordered pair $(\kappa,\eta)$. Three levels of counting must be distinguished: (a) attainable hull dimensions, i.e.\ which values $\eta$ occur; (b) hull-only multiplicity enumeration, i.e.\ how many codes have hull dimension $\eta$; (c) joint code-dimension/hull-dimension multiplicity enumeration, i.e.\ how many codes realize each pair $(\kappa,\eta)$. Previous work provides hull-dimension formulas for specified codes, attainable hull-dimension sets and their cardinalities, and counts at prescribed hull dimensions in related code families, but not the level-(c) distribution over the affine-algebra family studied here.% [UNVERIFIED - author must check against the published versions of sangwisut2015, debnathConstacyclic2023, debnathCorrection2023, debnathAffine2026]
Likewise, the multi-twisted generator-matrix and code-intersection frameworks \cite{eldinSole2026,eldinLeroy2026} describe individual hulls and intersections rather than an affine-product joint polynomial; specializing them does not by itself yield the labeled $(\kappa,\eta)$ multiplicity enumerator proved here.% [UNVERIFIED - author must check]
This paper answers the conditional question: for a fixed square-free affine algebra with labeled field components, simple-root moduli, and twists satisfying the compatibility condition \eqref{eq:compat}, can all $\lambda$-constacyclic codes over $\A$, which are in bijection with the labeled factor selections (Lemmas~\ref{lem:complete} and~\ref{lem:global-code}), be counted jointly by global code dimension and $k$-Galois-hull dimension? The answer is an exact product over reciprocal-factor orbits.

% AUTHOR NOTE (comparison paragraph, S2): fill in from the published versions and uncomment.
% In terms of the three levels (a)--(c), \cite{sangwisut2015} counts ____ (level __),
% \cite{debnathConstacyclic2023,debnathCorrection2023} count ____ (level __), and
% \cite{debnathAffine2026} counts ____ (level __); the present paper gives the level-(c)
% count for $\lambda$-constacyclic codes over $\A$ under \eqref{eq:compat}.
% If any of these works already gives the number of codes with hull dimension eta
% (level (b)) for the present family, present Corollary~\ref{cor:hull-dist} as a recovery.''', 'P5+S2')
span(r'Our contribution is the application-specific passage',
     r'the content is the boundary statistic it evaluates.',
r'''We state precisely what is standard and what is new here.
(i) Lemma~\ref{lem:ordinary-reciprocal} is the standard description of the Euclidean dual of a constacyclic code, and Theorem~\ref{thm:dual-generator} follows from it by applying the coordinatewise inverse Frobenius (Proposition~\ref{prop:dual-translation}).
(ii) Theorem~\ref{thm:hull-support} is the lcm/intersection form of the hull for the $k$-Galois dual over a compatible twist, in the spirit of the lcm/intersection descriptions used in the literature \cite{debnathConstacyclic2023,debnathAffine2026}.% [UNVERIFIED - author must check]
(iii) The trace of the two-state transfer matrix is standard closed-walk counting; Proposition~\ref{prop:closed} gives the same one-orbit polynomial in closed form, without matrices. The coefficient-level algorithm of Proposition~\ref{prop:algorithm} is a routine dynamic program.
(iv) What is new is the following: the labeled joint $(\kappa,\eta)$ enumerator over the CRT product, with orbit weights $w_O=m_sd_O$,
\[
\Epoly(u,z)=\sum_{C}u^{\kappa(C)}z^{\eta_k(C)}
 =\prod_{s}\prod_{O\in\Os}\operatorname{tr}\bigl(T_{w_O}(u,z)^{a_O}\bigr)
\]
(Theorem~\ref{thm:central}), where the sum runs over all $\lambda$-constacyclic codes over $\A$; and the conditional hull statistics at fixed code dimension $\kappa$ (Corollaries~\ref{cor:conditional} and~\ref{cor:conditional-variance}).''', 'P7')
span(r'The route is: affine-algebra CRT decomposition',
     r'data not recoverable in general from a hull-only marginal.',
     r'Figure~\ref{fig:pipeline} summarizes the route from the decomposition of $\A$ to the joint enumerator $\Epoly(u,z)$.', 'P8')
span(r'\caption{From the affine-algebra decomposition to the joint enumerator. Each step',
     r'exact joint $(K,H)$ multiplicities.}',
     r'\caption{From the affine-algebra decomposition to the joint enumerator $\Epoly(u,z)$.}', 'P8 caption')
rep(r'\fbox{code-first duality}', r'\fbox{$k$-Galois duality}', 'P8 figure box')
span(r'Validation combines exact symbolic enumeration with direct finite-case checks.',
     r'see Section~\ref{sec:examples}.',
r'''Validation combines exact coefficient computation with direct finite-case verification. For small instances in characteristics $2$, $3$ and $5$, every factor selection is checked at the code level by computing the $k$-Galois dual and the hull by independent linear algebra. For $q=32$, $n=31$, the polynomial $\Epoly(u,z)$ is obtained by an exact trace/dynamic-programming computation from the orbit data, without enumerating the $2^{31}$ selections; see Section~\ref{sec:verification}.''', 'P9+S11')
span(r'The counts are of labeled factor selections; no quotient by automorphisms',
     r'no quantum conclusion is drawn here.',
     r'The paper treats simple-root moduli and compatible twists and counts labeled codes; the precise scope is listed at the end of Section~\ref{sec:conclusion}.', 'S3')
span(r'The rest of the paper is organized as follows.',
     r'closes with the scope of the results and directions for future work.',
r'''The rest of the paper is organized as follows. Section~\ref{sec:prelim} introduces the basic setting, including the square-free affine algebra and its decomposition, constacyclic codes through labeled factor selections, and the $k$-Galois pairing in its global form. Section~\ref{sec:duality} develops $k$-Galois duality for component codes, including the inverse-Frobenius reciprocal and the associated compatibility condition, the dual-generator description, and the resulting hull-support formula and cyclic boundary statistic. Section~\ref{sec:enumeration} develops the exact enumeration framework: the one-orbit polynomial, its transfer-matrix representation and closed form, the global joint enumerator, its consequences, and the coefficient computation. Section~\ref{sec:examples} presents worked examples and verification, and Section~\ref{sec:conclusion} summarizes the results, the main findings and the scope.''', 'P11')

# ------------------------------------------------------------ Section 2
rep(r'The symbols are collected for reference in a summary paragraph at the end of the section.',
    r'The symbols are collected in Table~\ref{tab:nomenclature}.', 'S4 pointer')
rep(r'\subsection{Constacyclic codes and labeled factor selections}',
    r'\subsection{Constacyclic codes and labeled factor selections}\label{sec:selections}', 'label sec:selections')
rep(r'We use $\varepsilon=1$ for a factor selected in the generator; thus a selected factor contributes to codimension rather than directly to code dimension.',
    r'\emph{Selection convention.} Throughout, the value $1$ means that a factor is \emph{selected}, i.e.\ it divides the generator $g_{J_s}$; the value $0$ means that it is not selected. A selected factor therefore contributes to the codimension, not to the code dimension.', 'P12')
rep(r'This is a labeled factor-selection count: no quotient by rotations, automorphisms, isometries, or code equivalence is taken.',
    r'This is a labeled factor-selection count: no quotient by rotations, automorphisms, isometries, or code equivalence is taken. The count does not depend on the order of the component labels.', 'P13')

P14 = r'''
\begin{definition}[Constacyclic code over $\A$]\label{def:constacyclic-A}
Let $\lambda\in\A^{*}$. The \emph{$\lambda$-shift} on $\A^{n}$ is
\[
T_\lambda(c_0,c_1,\dots,c_{n-1})=(\lambda c_{n-1},c_0,\dots,c_{n-2}).
\]
A \emph{$\lambda$-constacyclic code of length $n$ over $\A$} is an $\A$-submodule $C\subseteq\A^{n}$ with $T_\lambda(C)\subseteq C$. Under the coefficient-vector identification $\A^{n}\cong\mathcal M_\lambda=\A[x]/\langle x^{n}-\lambda\rangle$, $(c_0,\dots,c_{n-1})\mapsto\sum_i c_ix^{i}$, the map $T_\lambda$ becomes multiplication by $x$. Hence the $\lambda$-constacyclic codes over $\A$ are exactly the $\A[x]$-submodules (equivalently, the ideals) of $\mathcal M_\lambda$.
\end{definition}

\begin{remark}
The definition requires $\A$-linearity. A subspace of $\A^{n}$ that is only $\F_q$-linear and closed under $T_\lambda$ need not be an $\A$-submodule, and such subspaces are not counted in this paper.
\end{remark}

For $J=(J_s)_s\in\mathscr C$ put $C(J)=\prod_{s=1}^{N}C_s(J_s)\subseteq\prod_{s=1}^{N}K_s^n\cong\A^n$; Lemma~\ref{lem:global-code} below shows that $C(J)$ is a $\lambda$-constacyclic code over $\A$.

\begin{lemma}[Completeness of factor selections]\label{lem:complete}
Let $e_1,\dots,e_N$ be the primitive idempotents of $\A$ corresponding to the fixed decomposition \eqref{eq:decomp} (so $e_s$ is the tuple with $1$ in component $s$ and $0$ elsewhere). Every $\lambda$-constacyclic code $C\subseteq\A^{n}$, that is, every $\A[x]$-submodule $C$ of $\mathcal M_\lambda$, satisfies
\[
C=\bigoplus_{s=1}^{N} e_sC,
\]
where each $e_sC$ is an ideal of $e_s\mathcal M_\lambda\cong K_s[x]/\langle x^{n}-\lambda_s\rangle$. Consequently there is a unique $J=(J_s)_s\in\mathscr C$ with $C=C(J)$.
\end{lemma}

\begin{proof}
\emph{Step 1 (splitting).} The elements $e_s\in\A$ satisfy $e_se_t=\delta_{st}e_s$ and $\sum_s e_s=1$. Since $C$ is an $\A$-module, $e_sC\subseteq C$ for every $s$. Any $c\in C$ can be written as $c=\sum_s e_sc$, so $C=\sum_s e_sC$. The sum is direct: if $\sum_s e_sc_s=0$ with $c_s\in C$, multiplying by $e_t$ gives $e_tc_t=0$ for every $t$.

\emph{Step 2 (components).} Multiplication by $e_s$ gives a surjective $\A[x]$-linear map $\mathcal M_\lambda\to e_s\mathcal M_\lambda$. We have $e_s\A=K_s$ and $e_s(x^{n}-\lambda)=e_s(x^{n}-\lambda_s)$. Therefore
\[
e_s\mathcal M_\lambda= e_s\A[x]\big/\langle e_s(x^{n}-\lambda)\rangle
 \cong K_s[x]/\langle x^{n}-\lambda_s\rangle,
\]
and this is the $s$-th factor of \eqref{eq:ambient}. The set $e_sC$ is the image of an $\A[x]$-submodule under an $\A[x]$-linear map, so it is an $\A[x]$-submodule of $e_s\mathcal M_\lambda$. On $e_s\mathcal M_\lambda$ the ring $\A$ acts through the projection $\A\to K_s$. So $e_sC$ is a $K_s[x]$-submodule of $K_s[x]/\langle M_s\rangle$, which is the same thing as an ideal.

\emph{Step 3 (identification).} By Lemma~\ref{lem:factor-selection}, every ideal of the simple-root quotient $K_s[x]/\langle M_s\rangle$ equals $C_s(J_s)=\langle g_{J_s}\rangle$ for exactly one $J_s\subseteq\Fs$. Applying this to each $e_sC$ and using Step~1 gives $C=\bigoplus_s C_s(J_s)=C(J)$ with $J=(J_s)_s$.

\emph{Uniqueness.} If $C(J)=C(J')$, multiplying by $e_s$ gives $C_s(J_s)=C_s(J'_s)$ for every $s$, and Lemma~\ref{lem:factor-selection} gives $J_s=J'_s$ for every $s$.
\end{proof}

'''
P15 = r'''\begin{lemma}[Global CRT ambient module and factor-selection codes]\label{lem:global-code}
Recall the definition of $C(J)$ for $J\in\mathscr C$. Equivalently, $C(J)$ is the ideal of $\mathcal M_\lambda$ generated by the tuple $g_J=(g_{J_s})_s$. By Definition~\ref{def:constacyclic-A}, each $C(J)$ is a $\lambda$-constacyclic code over $\A$, and different labeled tuples $J\neq J'$ give different codes. Together with Lemma~\ref{lem:complete}, the map
\[
\mathscr C\longrightarrow\{\lambda\text{-constacyclic codes of length }n\text{ over }\A\},\qquad J\longmapsto C(J),
\]
is a bijection.
\end{lemma}

\begin{proof}
The product and coefficient-vector identifications are the CRT isomorphisms \eqref{eq:ambient}. Each $C_s(J_s)$ is an ideal of $K_s[x]/\langle M_s\rangle$, so $C(J)$ is an ideal of $\mathcal M_\lambda$. It is the ideal generated by $g_J$, and it is a $\lambda$-constacyclic code over $\A$ by Definition~\ref{def:constacyclic-A}. If $J\neq J'$, choose $s$ with $J_s\neq J'_s$. Lemma~\ref{lem:factor-selection} gives $C_s(J_s)\neq C_s(J'_s)$, so the two products have different $s$-components (injectivity). Surjectivity is Lemma~\ref{lem:complete}.
\end{proof}'''
span(r'\begin{lemma}[Global CRT ambient module and factor-selection code]\label{lem:global-code}',
     r'are different global codes.' + '\n' + r'\end{proof}',
     P14 + P15, 'P14+EDIT A+P15')

rep(r'\subsection{The code-first Galois pairing and the global code}',
    r'\subsection{The \texorpdfstring{$k$}{k}-Galois pairing and the global code}', 'P16 title')
rep(r'The code-first second-slot pairing is', r'The $k$-Galois pairing is', 'P16 pairing')
rep(r'The code-first dual is', r'The $k$-Galois dual is', 'P16 dual')
rep(r'and the code-first hull is', r'and the $k$-Galois hull is', 'P16 hull')
rep(r'\begin{proposition}[Code-first dual translation]', r'\begin{proposition}[$k$-Galois dual translation]', 'P17 title')
rep(r'The code-first condition is', r'The $k$-Galois condition is', 'P17 proof')
rep(r'[Global Frobenius and code-first pairing]', r'[Global Frobenius and $k$-Galois pairing]', 'P18 a')
rep(r'global code-first pairing', r'global $k$-Galois pairing', 'P18 b')
rep(r'[Global code-first dual decomposition]', r'[Global $k$-Galois dual decomposition]', 'P18 c')
rep(r'The global code-first hull decomposes as', r'The global $k$-Galois hull decomposes as', 'P18 d')

S4 = r'''\begin{table}[ht]
\centering
\caption{Nomenclature.}\label{tab:nomenclature}
\small
\begin{tabularx}{\textwidth}{@{}lX@{}}
\toprule
$\F_q$, $q=p^{e}$ & base field \\
$K_s=\F_{q^{m_s}}$, $d_s=em_s$ & component field and its absolute degree \\
$\sigma_{s,k}$, $\rho_{s,k}$ & $a\mapsto a^{p^{k}}$ and its inverse $a\mapsto a^{p^{d_s-k}}$, $0\le k<e$ \\
$\langle x,y\rangle_{s,k}$, $\Dk$ & $k$-Galois pairing and $k$-Galois dual \\
$\A$ & square-free affine algebra, a labeled product of the $K_s$ \\
$n$, $\lambda_s$ & length with $\gcd(n,p)=1$; component twist \\
$\lambda_s^{1+p^{d_s-k}}=1$ & compatibility condition \\
$\Fs$, $J_s$ & irreducible factors of $M_s$; labeled selection of generator factors \\
$\tau_{s,k}$, $\Os$ & reciprocal factor permutation; its set of orbits (Definition~\ref{def:orbits}) \\
$a_O$, $d_O$, $w_O=m_sd_O$ & orbit length, common factor degree, $\F_q$-weight \\
$\varepsilon_{O,i}$, $b_O$ & selection indicator; cyclic $1$-to-$0$ count \eqref{eq:boundary} \\
$T_w(u,z)$ & weighted transfer matrix (rows: source state, columns: destination state) \\
$\kappa(C)$, $\eta_k(C)$ & $\F_q$-dimension of a code and of its $k$-Galois hull \\
$\Epoly(u,z)$, $\mathcal H(z)$ & joint enumerator and hull polynomial \\
\bottomrule
\end{tabularx}
\end{table}'''
span(r'The notation and standing assumptions used in the component and global constructions are collected below',
     r'is the code/hull joint enumerator for labeled codes.', S4, 'S4 nomenclature')

# ------------------------------------------------------------ Section 3
rep(r'This section works out the code-first duals and hull supports of component constacyclic codes: the inverse-Frobenius reciprocal and its compatibility condition, the dual generator together with the candidate-first comparison, and finally',
    r'This section works out the $k$-Galois duals and hull supports of component constacyclic codes: the inverse-Frobenius reciprocal and its compatibility condition, the dual generator, and finally', 'P20')
span(r'\begin{lemma}[Root action]\label{lem:root-action}',
     r'\rho_{s,k}\left(\alpha^{-r}f(\alpha)\right)=0.' + '\n' + r'\]' + '\n' + r'\end{proof}',
r'''\begin{lemma}[Root action]\label{lem:root-action}
Let $f(x)=\sum_{i=0}^{r}f_ix^{i}\in K_s[x]$ be monic with $f_0\neq0$, let $L\supseteq K_s$ be a finite field containing a root $\alpha$ of $f$, and let $g=f^{\#_{s,k}}$ be as in \eqref{eq:reciprocal}. Then $g\bigl(\alpha^{-p^{d_s-k}}\bigr)=0$. Thus the induced root map is $\alpha\mapsto\alpha^{-p^{d_s-k}}$.
\end{lemma}

\begin{proof}
Extend $\rho=\rho_{s,k}$ to $L$ by $\rho(a)=a^{p^{d_s-k}}$; this is a field automorphism of $L$ whose restriction to $K_s$ is $\rho_{s,k}$. Let $\sigma_L:=\rho^{-1}$ on $L$; its restriction to $K_s$ is $\sigma_{s,k}=\rho_{s,k}^{-1}$. For $y\in L$ put
\[
(\rho f)(y):=\rho\bigl(f(\sigma_L(y))\bigr)
 =\sum_{i=0}^{r}\rho(f_i)\,\rho(\sigma_L(y))^{i}
 =\sum_{i=0}^{r}\rho(f_i)\,y^{i},
\]
using that $\rho$ is a ring homomorphism. By \eqref{eq:reciprocal},
\[
g(x)=\rho(f_0)^{-1}\sum_{i=0}^{r}\rho(f_i)x^{r-i}
 =\rho(f_0)^{-1}x^{r}\,(\rho f)(x^{-1}).
\]
Put $\beta=\rho(\alpha^{-1})=\alpha^{-p^{d_s-k}}$, which is nonzero since $f_0\ne0$ forces $\alpha\ne0$. Then $\beta^{-1}=\rho(\alpha)$, so $\sigma_L(\beta^{-1})=\alpha$, and
\[
g(\beta)=\rho(f_0)^{-1}\beta^{r}\,(\rho f)(\beta^{-1})
 =\rho(f_0)^{-1}\beta^{r}\,\rho\bigl(f(\alpha)\bigr)=0.
\]
Finally, if $\alpha^{n}=\lambda_s$ then $\beta^{n}=\rho(\alpha^{n})^{-1}=\rho(\lambda_s)^{-1}=\lambda_s^{-p^{d_s-k}}$.
\end{proof}''', 'P21')

rep(r'\subsection{Code-first duals and the candidate-first comparison}' + '\n\n' + r'The code-first dual of a component code can now be determined.',
    r'\subsection{\texorpdfstring{$k$}{k}-Galois duals}' + '\n\n' + r'The $k$-Galois dual of a component code can now be determined.', 'P22 title')
rep(r'\begin{theorem}[Code-first dual generator]', r'\begin{theorem}[$k$-Galois dual generator]', 'P22 thm title')
rep(r'Under the simple-root hypotheses, the code-first dual is generated', r'Under the simple-root hypotheses, the $k$-Galois dual is generated', 'P22 thm')

REM_CAND = r'''

\begin{remark}[Candidate-first convention]\label{rem:candidate}
This remark is used only in the comparison after Proposition~\ref{prop:lcm-bridge} and in the verification. Define
\[
D_{\mathrm{cand}}(C)=\Bigl\{y:\ \sum_i y_i\,\sigma_{s,k}(c_i)=0\text{ for every }c\in C\Bigr\}.
\]
\textup{(a)} For any $K_s$-linear code, without a constacyclic hypothesis,
\[
\Dk(C)=\rho_{s,k}(C^{\perpE}),\qquad D_{\mathrm{cand}}(C)=\sigma_{s,k}(C^{\perpE}),
\]
and therefore
\begin{equation}\label{eq:convention}
D_{\mathrm{cand}}(C)=\sigma_{s,k}^{2}\bigl(\Dk(C)\bigr).
\end{equation}
The two dual subspaces are not generally equal.
\emph{Proof.} The first relation is Proposition~\ref{prop:dual-translation}. For the candidate-first condition, substitute $y=\sigma_{s,k}(z)$: then $\sum_iy_i\sigma_{s,k}(c_i)=\sigma_{s,k}(\sum_iz_ic_i)$, which vanishes for every $c\in C$ exactly when $z\in C^{\perpE}$, giving $D_{\mathrm{cand}}(C)=\sigma_{s,k}(C^{\perpE})$. Applying $\sigma_{s,k}$ twice to the $k$-Galois relation gives \eqref{eq:convention}, since $\sigma_{s,k}^{2}(\rho_{s,k}(z))=\sigma_{s,k}(z)$. The two subspaces agree only when the square of the Frobenius happens to fix the dual subspace.

\textup{(b)} \emph{(Same-code hull dimension only.)} Let $B$ be a row basis of a finite-field-linear code $C$ and let $G=B\,\sigma(B)^{\mathsf T}$. Then both same-code hull dimensions equal $\dim(C)-\rank(G)$. In particular, the $k$-Galois and candidate-first pairings have the same same-code hull dimension and the same LCD decision. This does not identify the dual codes, hull subspaces, factor supports, or generator supports.
\emph{Proof.} Write codewords as $vB$ with row vectors $v$. For the $k$-Galois hull, $y=vB$ lies in $\Dk(C)$ exactly when $uB\,\sigma(B)^{\mathsf T}\sigma(v)^{\mathsf T}=0$ for every $u$, that is, $G\,\sigma(v)^{\mathsf T}=0$. Since $\sigma$ is a coordinatewise field automorphism, $\sigma(v)$ ranges over all row vectors as $v$ does, so the $k$-Galois hull has dimension $\dim(C)-\rank(G)$ by rank-nullity. For the candidate-first hull, $y=vB$ lies in $D_{\mathrm{cand}}(C)$ exactly when $vB\,\sigma(B)^{\mathsf T}\sigma(u)^{\mathsf T}=0$ for every $u$, that is, $vG=0$; this left nullspace has the same dimension $\dim(C)-\rank(G)$. The LCD assertion is the case $\rank(G)=\dim(C)$.
\end{remark}'''
rep(r'$\tau_{s,k}(\Fs\setminus J_s)$; these are the selected factors in' + '\n' + r'the dual generator.' + '\n' + r'\end{proof}',
    r'$\tau_{s,k}(\Fs\setminus J_s)$; these are the selected factors in' + '\n' + r'the dual generator.' + '\n' + r'\end{proof}' + REM_CAND, 'P23 insert')
rep(r'The code-first dual twist equals the original twist precisely when', r'The $k$-Galois dual twist equals the original twist precisely when', 'P24 a')
rep(r'If this condition fails, the code-first dual belongs to the transformed modulus', r'If this condition fails, the $k$-Galois dual belongs to the transformed modulus', 'P24 b')
REM_INC = r'''

\begin{remark}[Incompatible twists]\label{rem:incompatible}
If $\lambda_s^{1+p^{d_s-k}}\neq1$, the $k$-Galois dual of $C_s(J_s)$ is, by Theorem~\ref{thm:dual-generator}, a $\lambda_s^{-p^{d_s-k}}$-constacyclic code over the transformed modulus $x^{n}-\lambda_s^{-p^{d_s-k}}$. The hull of $C$ is then not constacyclic in general, so Theorem~\ref{thm:hull-support} and the orbit product of Theorem~\ref{thm:central} are not asserted in this case.
\end{remark}'''
span(r'We now compare the code-first dual with the candidate-first variant used for comparison.',
     r'The LCD assertion is the case $\rank(G)=\dim(C)$.' + '\n' + r'\end{proof}',
     REM_INC.strip('\n'), 'P23 delete old props + P25')

rep(r'\subsection{Hull support and the cyclic boundary statistic}' + '\n',
    r'''\subsection{Hull support and the cyclic boundary statistic}

\begin{definition}[Orbit set]\label{def:orbits}
Assume $\lambda_s^{1+p^{d_s-k}}=1$. The \emph{orbit set} $\Os$ is the set of cycles of the permutation $\tau_{s,k}$ of $\Fs$ (Proposition~\ref{prop:compatible-permutation}). For $O\in\Os$ write $a_O=|O|$, let $d_O$ be the common $K_s$-degree of its factors, and list $O=\{f_{O,1},\dots,f_{O,a_O}\}$ so that $\tau_{s,k}(f_{O,i})=f_{O,i+1}$, indices modulo $a_O$. Thus $\Fs=\bigsqcup_{O\in\Os}O$.
\end{definition}
''', 'P26')
rep(r'Under the compatible same-factor-set hypotheses, the code-first hull has factor support',
    r'Under the compatible same-factor-set hypotheses, the $k$-Galois hull has factor support', 'P27')
span(r'For a labeled selection $J=(J_s)_s$ and its global code $C(J)$, let $O\in\Os$ be a cycle of length $a_O$, indexed by',
     r'\varepsilon_i=\begin{cases}1,&f_i\in J_s,\\0,&f_i\notin J_s.\end{cases}' + '\n' + r'\]',
r'''For a labeled selection $J=(J_s)_s$ and its global code $C(J)$, let $O\in\Os$ be indexed as in Definition~\ref{def:orbits}. All factors in $O$ have a common degree $d_O$. Put
\[
w_O=m_s d_O,
\qquad
\varepsilon_{O,i}=\begin{cases}1,&f_{O,i}\in J_s,\\0,&f_{O,i}\notin J_s,\end{cases}
\]
which follows the selection convention of Section~\ref{sec:selections}. When the orbit is clear we write $\varepsilon_i=\varepsilon_{O,i}$.''', 'P28')
rep(r'take the normalized code-first reciprocal', r'take the normalized $k$-Galois reciprocal', 'P29')
rep(r'(see Theorem~8 of the arXiv version \cite{debnathAffinePreprint} for the explicit max-formula text).',
    r'(see Theorem~8 of the arXiv version \cite{debnathAffinePreprint} for the explicit max-formula text).% [UNVERIFIED - author must quote the theorem verbatim from the published version]' + '\n', 'P30 flag')
rep(r'the candidate-first and code-first dual subspaces are not identified. Their same-code hull dimensions can be compared by Proposition~\ref{prop:gram-invariance}.',
    r'the candidate-first and $k$-Galois dual subspaces are not identified. Their same-code hull dimensions can be compared by Remark~\ref{rem:candidate}(b).', 'P30')
rep(r'\caption{A reciprocal $\tau$-orbit of length $6$ with selection word $\varepsilon=110100$. The hull contribution is the weighted count of directed $1$-to-$0$ transitions (thick arrows) in \eqref{eq:boundary}.}',
    r'\caption{A reciprocal $\tau$-orbit of length $6$ with selection word $\varepsilon=110100$; thick arrows are the $1$-to-$0$ transitions counted in \eqref{eq:boundary}.}', 'caption orbit')

# ------------------------------------------------------------ Section 4
rep(r'The second form is integral because it equals the first form. In particular,', r'In particular,', 'P31')
P32 = r'''

\begin{proposition}[Closed form of the one-orbit trace]\label{prop:closed}
For an orbit of length $a\ge1$ and weight $w$, and for $1\le j\le a-1$ and $r\ge1$, the number of indexed cyclic binary words $\varepsilon\in\{0,1\}^{a}$ with exactly $j$ zeros (unselected factors) and exactly $r$ one-runs is
\[
N(a;j,r)=\frac{a}{r}\binom{j-1}{r-1}\binom{a-j-1}{r-1}.
\]
Consequently
\[
\operatorname{tr}\bigl(T_w(u,z)^{a}\bigr)
 =1+u^{wa}+\sum_{j=1}^{a-1}\sum_{r\ge1}
 \frac{a}{r}\binom{j-1}{r-1}\binom{a-j-1}{r-1}\,u^{wj}z^{wr}.
\]
\end{proposition}

\begin{proof}
\emph{Double counting.} Fix $1\le j\le a-1$, so $\varepsilon$ is not constant, and fix $r\ge1$. Call $i\in\mathbb{Z}/a$ a \emph{run start} of $\varepsilon$ if $\varepsilon_i=1$ and $\varepsilon_{i-1}=0$. Each one-run of a nonconstant cyclic word has exactly one run start, so a word with $r$ one-runs has exactly $r$ run starts. Let $\mathcal{P}$ be the set of pairs $(\varepsilon,i)$ where $\varepsilon$ has $j$ zeros and $r$ one-runs and $i$ is a run start of $\varepsilon$. Then $|\mathcal{P}|=r\,N(a;j,r)$.

\emph{Bijection.} Send $(\varepsilon,i)$ to $(i,v)$ with $v=(\varepsilon_i,\varepsilon_{i+1},\dots,\varepsilon_{i+a-1})$, the word read linearly from position $i$. Then $v$ starts with $1$ (as $\varepsilon_i=1$) and ends with $0$ (as $\varepsilon_{i-1}=0$). Hence $v$ is a linear word consisting of $2r$ maximal runs alternating $1,0,1,0,\dots,1,0$: $r$ one-runs with total length $a-j$ and $r$ zero-runs with total length $j$. (The cyclic runs of $\varepsilon$ are exactly the linear runs of $v$, because the cut between positions $i-1$ and $i$ lies at a $0\to1$ transition.) Conversely, any pair $(i,v)$ with $i\in\mathbb{Z}/a$ and $v$ of this shape gives, by placing $v$ cyclically starting at position $i$, a word with $j$ zeros, $r$ one-runs and run start $i$. The two maps are mutually inverse. Such words $v$ correspond to an ordered composition of $a-j$ into $r$ positive parts and an ordered composition of $j$ into $r$ positive parts, so their number is $\binom{a-j-1}{r-1}\binom{j-1}{r-1}$. Therefore
\[
r\,N(a;j,r)=|\mathcal{P}|=a\binom{j-1}{r-1}\binom{a-j-1}{r-1},
\]
which gives the formula.

\emph{Trace.} By Proposition~\ref{prop:trace}, $\operatorname{tr}(T_w^{a})$ is the sum over $\varepsilon\in\{0,1\}^{a}$ of $u^{w\cdot\#\{i:\varepsilon_i=0\}}z^{w\,b(\varepsilon)}$. By Proposition~\ref{prop:boundary-interpretation}, $b(\varepsilon)$ is the number of one-runs of a nonconstant word. The all-zero word gives $u^{wa}z^{0}$ and the all-one word gives $u^{0}z^{0}=1$. Grouping the nonconstant words by $(j,r)$ gives the stated sum.
\end{proof}

\begin{remark}
Summing over $j$ at fixed $r$ recovers $N(a,r)=2\binom{a}{2r}$, because both count the words with $r$ one-runs (Proposition~\ref{prop:orbit-poly}).
\end{remark}'''
rep(r'which is the displayed monomial after cyclic reindexing. The closed-walk expansion is proved here directly; the hull-specific content is the preceding identification of the boundary statistic.' + '\n' + r'\end{proof}',
    r'which is the displayed monomial after cyclic reindexing. The closed-walk expansion is proved here directly; the hull-specific content is the preceding identification of the boundary statistic.' + '\n' + r'\end{proof}' + P32, 'P32')
span(r'Enumeration convention. The CRT component labels are fixed once and for all',
     r'Coefficients therefore count labeled codes, not equivalence classes.' + '\n\n', '', 'P33')

P34 = r'''\begin{theorem}[Exact labeled joint enumerator]\label{thm:central}
Under the standing hypotheses of Sections~\ref{sec:prelim} and~\ref{sec:duality}, with the orbit notation of Definition~\ref{def:orbits} and Sections~\ref{sec:orbit} and~\ref{sec:transfer}, let
\[
\A\cong\prod_{s=1}^{N}K_s,\qquad K_s=\F_{q^{m_s}},\qquad
\lambda=(\lambda_s)_s\in\A^{*},
\]
with $q=p^{e}$, $d_s=em_s$, $0\le k<e$, $\gcd(n,p)=1$ (so every $M_s$ has simple roots), fixed component labels, $\lambda$-constacyclic codes over $\A$ in the sense of Definition~\ref{def:constacyclic-A}, and
\[
\lambda_s^{1+p^{d_s-k}}=1\qquad(1\le s\le N).
\]
For a labeled factor selection $J=(J_s)_s$, the global code is the CRT product
\[
C(J)=\prod_{s=1}^{N}C_s(J_s)\subseteq\A^{n},
\]
and its global $k$-Galois dual and hull are defined by the $\A$-valued pairing of Lemma~\ref{lem:global-pairing}:
\[
D_{\A,k}(C(J))=\{y:\langle c,y\rangle_{\A,k}=0_{\A}\ \text{for every } c\in C(J)\},
\qquad
\Hull_{\A,k}(C(J))=C(J)\cap D_{\A,k}(C(J)).
\]
For every orbit $O\in\Os$, let $a_O$ be its length, let $d_O$ be its common factor degree, and put $w_O=m_sd_O$. With $\varepsilon_{O,i}$ as in Proposition~\ref{prop:boundary}, set
\begin{equation}\label{eq:KH}
\begin{aligned}
\kappa(C(J)) &:= \dim_{\F_q}C(J)
 =\sum_{s,O,i}w_O(1-\varepsilon_{O,i}),\\
\eta_k(C(J)) &:= \dim_{\F_q}\Hull_{\A,k}(C(J))
 =\sum_{s,O,i}w_O\,\varepsilon_{O,i}(1-\varepsilon_{O,i+1}).
\end{aligned}
\end{equation}
With
\[
T_w(u,z)=\begin{pmatrix}u^{w}&1\\ u^{w}z^{w}&1\end{pmatrix},
\]
the exact joint generating polynomial is
\begin{equation}\label{eq:joint}
\begin{aligned}
\Epoly(u,z)
 &=\sum_{J\in\mathscr C}u^{\kappa(C(J))}z^{\eta_k(C(J))}\\
 &=\prod_{s=1}^{N}\prod_{O\in\Os}
 \operatorname{tr}\bigl(T_{w_O}(u,z)^{a_O}\bigr).
\end{aligned}
\end{equation}
For every pair $(\kappa,\eta)$ of \eqref{eq:KH}, $[u^{\kappa}z^{\eta}]\,\Epoly(u,z)$ is the number of $\lambda$-constacyclic codes $C\subseteq\A^{n}$ (equivalently, by Lemmas~\ref{lem:complete} and~\ref{lem:global-code}, of labeled factor selections $J\in\mathscr C$) with global $\F_q$-code dimension $\kappa$ and global $k$-Galois $\F_q$-hull dimension $\eta$.
\end{theorem}

\begin{proof}
\emph{Product structure.} By Lemma~\ref{lem:factor-selection}, a labeled selection is a tuple $J=(J_s)_s$ with $J_s\subseteq\Fs$ arbitrary, so $\mathscr C=\prod_s 2^{\Fs}$. By Proposition~\ref{prop:compatible-permutation}, under $\lambda_s^{1+p^{d_s-k}}=1$ the permutation $\tau_{s,k}$ partitions each $\Fs$ into its orbits $O\in\Os$. With each orbit listed as in Definition~\ref{def:orbits}, a subset $J_s\subseteq\Fs$ is the same as a family of binary words $(\varepsilon_{O,i})_{i=1}^{a_O}$, one for each $O\in\Os$. Hence
\[
\mathscr C\;\cong\;\prod_{s=1}^{N}\prod_{O\in\Os}\{0,1\}^{a_O},
\]
and the word on each reciprocal-factor orbit is an independent coordinate.

\emph{Additivity.} Lemmas~\ref{lem:global-dual} and~\ref{lem:global-hull} identify the global dual and hull with the products of the component duals and hulls. Proposition~\ref{prop:global-dimensions} converts component dimensions to global $\F_q$-dimensions with the weights $w_O=m_sd_O$. Hence both statistics in \eqref{eq:KH} are sums over orbits: $\kappa$ by Lemma~\ref{lem:factor-selection}, and $\eta_k$ by Theorem~\ref{thm:hull-support} with Proposition~\ref{prop:boundary}.

\emph{Counting.} Proposition~\ref{prop:trace} enumerates each orbit coordinate with its code-dimension and hull-dimension weights. A product of generating polynomials convolves independent additive statistics, so the coefficient of $u^{\kappa}z^{\eta}$ in the orbit-trace product counts exactly the tuples of orbit words with total weights $(\kappa,\eta)$.

\emph{From selections to codes.} By Lemma~\ref{lem:global-code} (injectivity), distinct tuples give distinct codes. By Lemma~\ref{lem:complete} (surjectivity), every $\lambda$-constacyclic code over $\A$ arises from some tuple. So the coefficient counts $\lambda$-constacyclic codes over $\A$ with parameters $(\kappa,\eta)$.
\end{proof}'''
span(r'\begin{theorem}[Exact labeled joint enumerator]\label{thm:central}',
     r'Injectivity in Lemma~\ref{lem:global-code} turns these tuples into distinct labeled codes, giving the stated interpretation.' + '\n' + r'\end{proof}',
     P34, 'P34')

span(r'\begin{corollary}\label{cor:total}', r'which also follows directly from the bijection of Lemma~\ref{lem:factor-selection}.' + '\n' + r'\end{proof}',
r'''\begin{corollary}\label{cor:total}
The total number of $\lambda$-constacyclic codes of length $n$ over $\A$ is
\[
\Epoly(1,1)=2^{\sum_s|\Fs|}.
\]
\end{corollary}

\begin{proof}
At $u=z=1$, each local trace \eqref{eq:trace} counts the $2^{a_O}$ indexed binary words on its orbit. Multiplying over the orbit partition gives $2^{\sum_s|\Fs|}$. The same number follows directly from the bijection $J\mapsto C(J)$ of Lemmas~\ref{lem:complete} and~\ref{lem:global-code} and $|\mathscr C|=2^{\sum_s|\Fs|}$. (This count uses only Lemma~\ref{lem:factor-selection} and does not need the compatibility condition.)
\end{proof}''', 'P35')
rep(r'''\begin{equation}
\Epoly(u,1)=\prod_{s=1}^{N}\prod_{f\in\Fs}
\left(1+u^{m_s\deg(f)}\right).
\end{equation}
Thus $[u^K]\Epoly(u,1)$ counts labeled codes of global code dimension $K$. This is a marginal distribution and does not identify a dual convention.''',
r'''\begin{equation}\label{eq:dimdist}
\Epoly(u,1)=\prod_{s=1}^{N}\prod_{f\in\Fs}
\left(1+u^{m_s\deg(f)}\right).
\end{equation}
Thus $[u^{\kappa}]\Epoly(u,1)$ counts labeled codes of global code dimension $\kappa$. This is a marginal distribution.''', 'P36')
rep(r'''H_{\A,n,\lambda,k}(z)=\Epoly(1,z)''', r'''\mathcal H(z)=\Epoly(1,z)''', 'P37 a')
rep(r'''Consequently,
\[
[z^H]H_{\A,n,\lambda,k}(z)
\]
counts labeled codes with code-first hull dimension $H$.''',
r'''Consequently, $[z^{\eta}]\,\mathcal H(z)$ counts labeled codes with $k$-Galois hull dimension $\eta$.''', 'P37 b')
rep(r'\#\{C:H_k(C)=0\}=2^{\sum_s|\Os|}.', r'\#\{C:\eta_k(C)=0\}=2^{\sum_s|\Os|}.', 'P38')
rep(r'''\begin{equation}
\#\{C:\eta_k''', r'''\begin{equation}\label{eq:lcd}
\#\{C:\eta_k''', 'P38 label')
rep(r'''\begin{equation}
\mathbb E[H_k]''', r'''\begin{equation}\label{eq:mean}
\mathbb E[\eta_k]''', 'P40')
rep(r'''\begin{equation}
\operatorname{Var}(H_k)''', r'''\begin{equation}\label{eq:var}
\operatorname{Var}(\eta_k)''', 'P41 display')
span(r'For $a\geq3$, the covariance calculation for the cyclic indicators gives $a/16$',
     r'Independent orbits add their variances.',
r'''Under the uniform measure on $\mathscr C$ the indicators $\varepsilon_{O,i}$ are independent $\mathrm{Bernoulli}(1/2)$ variables, because $\mathscr C\cong\prod_{s,O}\{0,1\}^{a_O}$ (proof of Theorem~\ref{thm:central}). Fix an orbit of length $a$ and weight $w$, and put $X_i=\varepsilon_{O,i}(1-\varepsilon_{O,i+1})$ with indices modulo $a$. Its contribution to $\eta_k$ is $w\sum_{i}X_i$.

\emph{Variances.} $X_i$ is an indicator with $\Pr(X_i=1)=1/4$, so $\operatorname{Var}X_i=\tfrac14-\tfrac1{16}=\tfrac3{16}$.

\emph{Case $a\ge3$.} Adjacent indicators satisfy $X_iX_{i+1}=\varepsilon_{O,i}(1-\varepsilon_{O,i+1})\varepsilon_{O,i+1}(1-\varepsilon_{O,i+2})=0$, hence $\operatorname{Cov}(X_i,X_{i+1})=0-\tfrac1{16}=-\tfrac1{16}$. If $X_i$ and $X_j$ are not adjacent, i.e.\ $\{i,i+1\}\cap\{j,j+1\}=\emptyset$, they are functions of disjoint sets of independent variables and hence independent. (For $a=3$ every two distinct indicators are adjacent, so this case is empty.) Since $a\ge3$, each $i$ has exactly two distinct neighbours $i\pm1$, so there are $2a$ ordered adjacent pairs. Therefore
\[
\operatorname{Var}\Bigl(\sum_i X_i\Bigr)
 = a\cdot\tfrac3{16}+2a\cdot\bigl(-\tfrac1{16}\bigr)
 = a\Bigl(\tfrac3{16}-\tfrac2{16}\Bigr)=\tfrac{a}{16},
\]
and the orbit contributes $a w^{2}/16$.

\emph{Case $a=2$.} Here $X_1=\varepsilon_{O,1}(1-\varepsilon_{O,2})$ and $X_2=\varepsilon_{O,2}(1-\varepsilon_{O,1})$ are mutually exclusive, and $X_1+X_2=1$ exactly when $\varepsilon_{O,1}\ne\varepsilon_{O,2}$. So $X_1+X_2$ is $\mathrm{Bernoulli}(1/2)$ with variance $1/4$, and the weighted contribution is $w^{2}/4$.

\emph{Case $a=1$.} $X_1=\varepsilon_{O,1}(1-\varepsilon_{O,1})=0$.

Distinct orbits involve disjoint independent variables, so their contributions are independent and the variances add, giving \eqref{eq:var}.''', 'P41 proof')

span(r'\begin{corollary}[Dimension-conditioned hull statistics]\label{cor:conditional}',
     r'\eqref{eq:conditional-variance}. No independence of $K$ and $H$ is' + '\n' + r'assumed.' + '\n' + r'\end{proof}',
r'''\begin{corollary}[Dimension-conditioned hull statistics]\label{cor:conditional}
For an integer $\kappa$ and $j\in\{0,1,2\}$ put
\[
\Phi_j(\kappa)=\sum_{\eta}\eta(\eta-1)\cdots(\eta-j+1)\,
 [u^{\kappa}z^{\eta}]\,\Epoly(u,z)
 =[u^{\kappa}]\,\frac{\partial^{j}\Epoly(u,z)}{\partial z^{j}}\Big|_{z=1},
\]
so that $\Phi_0(\kappa)=[u^{\kappa}]\,\Epoly(u,1)$ (empty product $=1$). Call $\kappa$ attainable if $\Phi_0(\kappa)>0$. Under the uniform measure on labeled selections of code dimension $\kappa$,
\begin{equation}\label{eq:conditional}
\Pr(\eta_k=\eta\mid\kappa(C)=\kappa)
 =\frac{[u^{\kappa}z^{\eta}]\,\Epoly(u,z)}{\Phi_0(\kappa)},\qquad
\mathbb E[\eta_k\mid\kappa(C)=\kappa]=\frac{\Phi_1(\kappa)}{\Phi_0(\kappa)}.
\end{equation}
These ratios are undefined when $\Phi_0(\kappa)=0$.
\end{corollary}

\begin{proof}
The denominator counts the $\Phi_0(\kappa)$ distinct labeled codes in the conditioning event by Theorem~\ref{thm:central}. Its numerator counts those with hull dimension $\eta$. Differentiating a monomial $z^{\eta}$ at $z=1$ weights it by $\eta$, which gives $\Phi_1(\kappa)$ and proves the expectation formula.
\end{proof}

\begin{corollary}[Dimension-conditioned second moment and variance]\label{cor:conditional-variance}
Under the hypotheses and notation of Corollary~\ref{cor:conditional}, for $\Phi_0(\kappa)>0$ the exact conditional factorial second moment and variance are
\begin{equation}\label{eq:conditional-variance}
\mathbb E[\eta_k(\eta_k-1)\mid\kappa(C)=\kappa]=\frac{\Phi_2(\kappa)}{\Phi_0(\kappa)},
\qquad
\operatorname{Var}(\eta_k\mid\kappa(C)=\kappa)
 =\frac{\Phi_2(\kappa)+\Phi_1(\kappa)}{\Phi_0(\kappa)}
 -\Bigl(\frac{\Phi_1(\kappa)}{\Phi_0(\kappa)}\Bigr)^{2}.
\end{equation}
In particular these expressions are undefined if $\Phi_0(\kappa)=0$.
\end{corollary}

\begin{proof}
For each coefficient $c_{\kappa,\eta}=[u^{\kappa}z^{\eta}]\,\Epoly(u,z)$, first and second $z$-differentiation at $z=1$ give $\eta\,c_{\kappa,\eta}$ and $\eta(\eta-1)\,c_{\kappa,\eta}$, respectively; summing over $\eta$ gives $\Phi_1(\kappa)$ and $\Phi_2(\kappa)$. Divide by $\Phi_0(\kappa)$. Finally $\eta^{2}=\eta(\eta-1)+\eta$ and the usual variance identity give \eqref{eq:conditional-variance}. No independence of $\kappa$ and $\eta$ is assumed.
\end{proof}''', 'P42+P43')

span(r'\begin{proposition}[Orbit dynamic-programming cost]\label{prop:algorithm}',
     r'reports exact symbolic coefficient counts. The smaller bit-word enumerator is' + '\n' + r'a boundary-statistic reference, not a direct linear-algebra baseline; the $2^{31}$ row is not an exhaustive direct run.',
r'''\begin{proposition}[Orbit dynamic-programming cost]\label{prop:algorithm}
Assume the compatible orbit lengths and weights have already been computed. Put $N_F=\sum_{s,O}a_O=\sum_s|\Fs|$ and $W=\sum_{s,O}a_Ow_O=n\sum_s m_s$. The full bivariate coefficient polynomial \eqref{eq:joint} can be formed by tracking two starting and current states around each orbit. A straightforward dense implementation uses $O\bigl(N_F\,(W+1)(\lfloor W/2\rfloor+1)\bigr)$ integer additions and $O\bigl((W+1)(\lfloor W/2\rfloor+1)\bigr)$ stored integer coefficients. These are arithmetic-operation bounds, not bit-complexity bounds; factorization and orbit construction are excluded.
\end{proposition}

\begin{proof}
\emph{Array size.} Code dimensions lie in $[0,W]$. A word on an orbit of length $a$ has at most $\lfloor a/2\rfloor$ one-runs (Proposition~\ref{prop:boundary-interpretation}), so $\eta\le\sum_{s,O}w_O\lfloor a_O/2\rfloor\le W/2$. Every coefficient array is therefore indexed by $[0,W]\times[0,\lfloor W/2\rfloor]$, i.e.\ it has $(W+1)(\lfloor W/2\rfloor+1)$ entries.

\emph{Recursion.} Keep a running global array $G$, initially the constant polynomial $1$. For an orbit of length $a$ and each starting state $s_0\in\{0,1\}$, initialise the two current-state arrays with $G$ in state $s_0$ and $0$ in the other state. Transition $(r,t)$ shifts an entry by $(w(1-t),\,wr(1-t))$ and adds it to state $t$. After $a$ transitions, keep the array in state $s_0$ (closed walks). The sum over $s_0=0,1$ is the new $G$, and it equals $G\cdot\operatorname{tr}(T_w^{a})$ by Proposition~\ref{prop:trace}. Because each orbit starts from the running array $G$, no separate polynomial convolution per orbit is needed.

\emph{Cost.} Each step performs four transitions for each of the two starting states, each costing one pass over an array. There are $N_F$ steps in total, which gives the time bound; a constant number of arrays gives the space bound. Coefficients can have $O(N_F)$ bits, so integer additions are not unit-cost in a bit-complexity model.
\end{proof}

Naive selection-by-selection enumeration visits $2^{N_F}$ codes. The dynamic program evaluates the realizable $\F_{32}$ case of Table~\ref{tab:verification} directly from its orbit data.''', 'P44+P45+S5')

# ------------------------------------------------------------ Section 5
rep(r'Theorem~\ref{thm:central} is illustrated below with worked examples, followed by a summary of computational verification. The computations check finite instances; they do not prove the general statements. The theorems are characteristic-independent; the verification computations were performed over $\mathrm{GF}(2^m)$ fields, covering field arithmetic, modulus factorization, dual and hull construction, Gram ranks, orbit enumeration, transfer-matrix evaluation, and global products.',
    r'Theorem~\ref{thm:central} is illustrated below with worked examples, followed by the verification of the formulas.', 'S6 sec intro')
rep(r'The joint $(K,H)$ multiplicities, in agreement with', r'The joint $(\kappa,\eta)$ multiplicities, in agreement with', 'P49 a')
rep(r'$K\backslash H$', r'$\kappa\backslash\eta$', 'P49 header')
rep(r'Among the $35$ three-dimensional codes, the table gives $12$, $21$, and $2$ codes with hull dimensions $1$, $2$, and $3$, respectively. Hence the conditional mean at $K=3$ is $60/35=12/7$, illustrating Corollary~\ref{cor:conditional} and Equation~\eqref{eq:conditional}.',
    r'Among the $\Phi_0(3)=35$ three-dimensional codes, the table gives $12$, $21$, and $2$ codes with hull dimensions $1$, $2$, and $3$, respectively. Hence the conditional mean at $\kappa=3$ is $\Phi_1(3)/\Phi_0(3)=60/35=12/7$, illustrating Corollary~\ref{cor:conditional} and Equation~\eqref{eq:conditional}. With $\Phi_2(3)=54$, Corollary~\ref{cor:conditional-variance} gives the conditional variance $78/245$.', 'P49+P52')

S6 = r'''\subsection{Verification}\label{sec:verification}

Two independent computations are compared with the formulas. The exact computation evaluates $\Epoly(u,z)$ from the orbit data by the trace recursion of Proposition~\ref{prop:algorithm}, without enumerating selections. The direct computation builds, for each selection, a generator matrix $B$ of $C$ and the $k$-Galois dual $D=\rho(\operatorname{null}B)$, and obtains $\dim\Hull_k(C)=\dim C+\dim D-\dim(C+D)$. Characteristics $3$ and $5$ are included because signs and normalizations in \eqref{eq:reciprocal} are invisible when $-1=1$. Table~\ref{tab:verification} lists the cases; all direct checks agree with the orbit prediction.

\begin{table}[ht]
\centering
\caption{Verification cases; ``direct'' counts codes whose hull was computed by linear algebra.}\label{tab:verification}
\footnotesize
\renewcommand{\arraystretch}{1.2}
\begin{tabularx}{\textwidth}{@{}lXrX@{}}
\toprule
Case & Parameters & Selections & Result \\
\midrule
$\F_4$ & $n=5$, $\lambda=1$, $k=1$; four components & $4096$ & 65 joint terms; direct 8/8 per component \\
$\F_8$ & $n=7$, $\lambda=1$, $k=1$; orbits $[1,6]$ & $128$ & 16 joint terms; $\mathbb E[\eta_k\mid\kappa=3]=12/7$, variance $78/245$; direct 128/128 \\
$\F_{16}$ over $\F_4$ & $n=5$, $\lambda=1$, $k=1$; orbits $[1,4]$ & $32$ & direct 32/32 \\
$\F_4$, twisted & $n=5$, $\lambda=\omega$, $k=1$; orbits $[1,2]$ & $8$ & direct 8/8 \\
$\F_4\times\F_{16}$ & $n=5$, $\lambda=(\omega,1)$, $k=1$ & $256$ & 40 joint terms; mean $3$, variance $2$; direct 256/256 \\
$\F_3$ & $n=4$, $\lambda\in\{1,-1\}$, $k=0$ & all & direct, 0 mismatches \\
$\F_9$ & $n=4$, $\lambda\in\{1,i,-1\}$, $k=1$ & all & direct, 0 mismatches \\
$\F_9$ & $n=8$, $\lambda=1$, $k=1$ & all & direct, 0 mismatches \\
$\F_{25}$ & $n=6$, $\lambda=1$, $k=1$ & all & direct, 0 mismatches \\
$\F_{32}$ & $n=31$, $\lambda=1$, $k=1$; orbits $[1,10,10,10]$ & $2^{31}$ & 248 joint terms, total $2^{31}$; direct on 150 random codes, 0 mismatches \\
\bottomrule
\end{tabularx}
\end{table}
% AUTHOR: the odd-characteristic rows and the 150-code F32 sample come from the
% reviewer-side re-run; re-run the check yourself and record the seed before submission.

'''
span(r'\subsection{Validation record}', r'The incompatible cases are diagnostics and are excluded from the compatible transfer theorem.' + '\n\n', S6, 'S6 5.2')

# ------------------------------------------------------------ Section 6 (S8 + EDIT B)
S8 = r'''\section{Conclusions}\label{sec:conclusion}

Every simple-root $\lambda$-constacyclic code over a square-free affine algebra corresponds to exactly one labeled factor selection, and for a compatible twist its $k$-Galois hull dimension is a weighted boundary count on reciprocal-factor orbits. This gives an exact bivariate enumerator of all such codes by code dimension and hull dimension.

The main findings are:
\begin{enumerate}
\item The labeled factor selections are in bijection with the $\lambda$-constacyclic codes over $\A$ (Lemmas~\ref{lem:complete} and~\ref{lem:global-code}); this needs only the square-free, simple-root and fixed-label hypotheses, and compatibility is used from the dual generator onward.
\item The hull dimension equals $\sum_{s,O}w_O\sum_i\varepsilon_{O,i}(1-\varepsilon_{O,i+1})$, with weights $w_O=m_sd_O$ (Proposition~\ref{prop:boundary}).
\item The joint enumerator is the product of the one-orbit traces $\operatorname{tr}(T_{w_O}^{a_O})$ (Theorem~\ref{thm:central}), and each trace has the closed form of Proposition~\ref{prop:closed}.
\item The number of codes with trivial hull is $2^{\sum_s|\Os|}$ (Corollary~\ref{cor:lcd}).
\item The mean and variance of the hull dimension are explicit orbit sums, with a separate term for orbits of length two (Corollaries~\ref{cor:mean} and~\ref{cor:variance}).
\item At every attainable code dimension, the conditional distribution, mean and variance of the hull dimension follow from three coefficient sums $\Phi_0,\Phi_1,\Phi_2$ (Corollaries~\ref{cor:conditional} and~\ref{cor:conditional-variance}).
\end{enumerate}

The enumerator tells how many codes of a given length and dimension have a prescribed hull dimension and lists them through their factor selections. This is directly usable when searching for complementary-dual codes \cite{massey1992,sendrier2004} and for codes with a prescribed hull dimension in hull-based constructions \cite{brun2006,wildeBrun2008}.

\paragraph{Limitations.}
\begin{itemize}
\item Only simple-root moduli and compatible twists are covered; repeated-root settings \cite{dinh2010} and incompatible twists (Remark~\ref{rem:incompatible}) are outside the orbit product.
\item Codes are counted as labeled selections, not as equivalence classes, which would require a specified group action \cite{vanLintWilson2001}.
\end{itemize}
% AUTHOR: optional one-line future work (Burnside--Polya quotient counts, repeated-root
% ideals, two-modulus theory for incompatible twists) if the journal allows it.

'''
span(r'\section{Conclusion}\label{sec:conclusion}', r'and a two-modulus theory for incompatible twists.' + '\n\n', S8, 'S8+EDIT B')

n=t.count(r'D_{\CF}'); t=t.replace(r'D_{\CF}', r'\Dk'); log.append(f'global D_CF->Dk x{n}')
open(DST, 'w').write(t)
print(len(log), 'edits applied')
