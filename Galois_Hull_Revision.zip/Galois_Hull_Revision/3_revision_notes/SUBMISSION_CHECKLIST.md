# Submission checklist (fill before journal upload)

## Must do

- [ ] **Authors**: replace `\author{}` in `manuscript/main.tex` with full author
      names, affiliations, and corresponding-author email (keep the anonymous
      version only if the journal uses double-blind review).
- [ ] **Acknowledgments/funding**: add the statement where marked
      `TODO (submission)` (before the bibliography), if required.
- [ ] **Competing interests**: most Q1 journals (Elsevier/Springer/IEEE) ask
      for this in the submission portal; prepare the sentence in advance.
- [ ] **Rebuild the PDF** after the above edits and re-verify (commands below).

## Verify after any edit

```sh
cd manuscript
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

* Zero LaTeX warnings/errors/overfull boxes; all 33 citations and all
  cross-references resolve; PDF text contains no `[?]`, `[?, ?]`, `??`.

## Journal-specific (decide at submission)

- [ ] Initial submission in generic format is accepted by most Q1 outlets
      ("Your Paper Your Way"); switch to the journal class file only if/when
      the revision requires it.
- [ ] Add line numbers (`lineno` package) only if the journal asks for them.
- [ ] Author decision: no supplementary files and no code are shared with
      this submission. Do **not** upload code, results, logs, revision audits,
      or build notes — manuscript files only (`main.tex`, `references.bib`,
      `main.pdf` as the journal requires).

## Do not include in the journal package

* Code, results, logs, `REVISION_AUDIT.md`, `BUILD.md`, internal `README.md`
  files — these stay in the author's private archive only.
