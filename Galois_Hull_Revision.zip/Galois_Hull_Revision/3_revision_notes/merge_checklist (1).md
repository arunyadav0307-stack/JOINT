# Merge checklist for the revised paper (author)

Files: `patches_final.tex` (the header comment lists the 21 labels to add and the citation-key note) (59 numbered patches, ordered by position in the paper),
`Audit_Report_Galois_Hull_Enumerators.pdf` (the audit).

## 1. Author actions (things no editor can verify)
1. Content of [9] (fixed-dimension counts) - PATCH 3.
2. Content of [26,27] - PATCH 4.
3. Content of [30] in the Introduction - PATCH 4.
4. Priority sentence "but not the level-(c) distribution" - PATCH 5. Keep only if verified, else delete.
5. Sentence on [28,29] - PATCH 5.
6. Fill the comparison skeleton (three rows) and read the AUTHOR NOTE about Corollary 4.3 - PATCH 6.
7. "[26,30] lcm/intersection descriptions" in contribution (ii) - PATCH 7.
8. Figure 1: check labels/caption for the old dual name, K or H - PATCH 8. Also check Figure 2.
9. Quote verbatim the subfamily conditions and Theorem 8 of [33] (max-formula) - PATCH 30.
10. "Formula overlap" row and overlap sentence in Section 5.2 - PATCHES 50, 51.
11. Claims about [30] in the Conclusion - PATCH 55.
12. Repository URL ([URL - author]) in two places - PATCHES 47, 56.
13. GF(9) integer representations (4 has order 4, 2 is -1) - PATCH 57.
14. Re-run the appendix script yourself and record the seed. The odd-characteristic results and the
    F_32 150-code sample were obtained in the supervisor's and editor's sandboxes, not by you.
    Supervisor run of the script exactly as printed in the appendix:
    check(3,4,1,0)=(8,0); (3,4,2,0)=(4,0); (9,4,1,1)=(16,0); (9,4,4,1)=(4,0); (9,4,2,1)=(16,0);
    (9,8,1,1)=(256,0); (25,6,1,1)=(64,0); (32,31,1,1,sample=150)=(150,0), about 21 s.
15. arXiv ID of [33] - PATCH 58.
16. Check every bibliographic field against DOIs, especially the 2026 entries [17],[18],[20],[28],[29],[30]
    and the volume/article number of [8]. No patch covers this.
17. Confirm that "A-submodule" (Definition in PATCH 14) is the family you mean (not F_q-linear
    shift-invariant subspaces).
18. Decide whether the closed-form Proposition 12 stays in the main text.
19. Check Table 2 (PATCH 50) against your .tex: it was rebuilt from the PDF text.
20. Citation keys: PATCH 6 uses placeholder keys \cite{ref9}, \cite{ref26,ref27}, \cite{ref30} and PATCH 58 uses
    \bibitem{ref33}. Replace them by your real bibliography keys; the other patches write [9], [26,27], etc.

## 2. Instruction-style patches (apply by hand in the .tex)
PATCHES 18, 27, 29, 48, 49 and the rest of the paragraph in PATCH 52 give wording changes as comments.

## 3. Labels to add to unpatched text
See the header comment of `patches_final.tex`.

## 4. Numbering map (old -> new)
Lemma 1 -> 1; new completeness lemma = Lemma 2; old Lemmas 2..8 -> 3..9.
Prop 1-5 unchanged; Props 6,7 -> Remark (candidate-first); Prop 8..13 -> 6..11;
new closed form = Prop 12; Prop 14 -> Prop 13. Theorems 1-3, Corollaries 4.1-4.8 and
Equations (1)-(23) unchanged (keep (7) numbered inside the Remark, placed after Theorem 1).

## 5. Grep after merging (each should print nothing except where intended)
    grep -nE "code-first|code–first" main.tex
    grep -nE "candidate-first" main.tex                 # only inside the Remark, the Prop 7 remark, Conclusion
    grep -nE "K\(C\)|H_k\(C\)|A_K|B_K|C_K|\\\\mathscr\{E\}" main.tex
    grep -nE "\[u\^\{?K|z\^\{?H" main.tex
    grep -nE "[^{]E ?\(u|E ?\(1," main.tex               # old enumerator E(u,z) / E(1,1): must become \mathcal{E}
    grep -nE "18 Gram|73 planes|N2-B|symbolic (exhaustive )?enumeration" main.tex
    grep -nE "Lemma 7|Lemma 8|Proposition 1[1-4]" main.tex   # review each hit by eye: typed numbers must follow the new map
                                                          # (Proposition 11-13 are valid NEW numbers; 14 is not)
    grep -nE "UNVERIFIED|author must|URL - author|arXiv ID - author" main.tex   # nothing may remain at submission
