# Galois-hull enumerator paper: revised package

1_manuscript/  main.tex, references.bib, main.pdf  -> the files to submit to the journal
2_code/        hull_check.py  -> direct k-Galois hull check (pip install galois numpy; python hull_check.py)
               Not part of the journal upload (author decision: no code shared).
3_revision_notes/  original .tex, patch files, merge script, checklists  -> private record only

Build: cd 1_manuscript; pdflatex main; bibtex main; pdflatex main; pdflatex main

Before submission:
- grep -n "UNVERIFIED\|AUTHOR" main.tex   (10 comment markers: check claims, then delete)
- re-run hull_check.py yourself and record the seed (odd characteristic + F32 sample=150, seed 0)
- page 21: keep the "Limitations." heading on the same page as its bullets
- author names, funding, competing interests (see SUBMISSION_CHECKLIST.md)
